# Manuals included in this package

- [README](APPLICATIONS/README.md)
- [AP_OIL_GUIDE](DOC/GUIDES/AP/AP_OIL_GUIDE.md)
- [ADDRESS_PRACTICES](DOC/GUIDES/ASM/ADDRESS_PRACTICES.md)
- [ASM_ABI_V1](DOC/GUIDES/ASM/ASM_ABI_V1.md)
- [ASM_CALL_MAP](DOC/GUIDES/ASM/ASM_CALL_MAP.md)
- [ASM_DIALECT_CROSSWALK](DOC/GUIDES/ASM/ASM_DIALECT_CROSSWALK.md)
- [ASM_USER_GUIDE](DOC/GUIDES/ASM/ASM_USER_GUIDE.md)
- [SIZE_REDUCTION_2026-09-15](DOC/GUIDES/ASM/SIZE_REDUCTION_2026-09-15.md)
- [CAPABILITIES](DOC/GUIDES/CAPABILITIES.md)
- [GLOSSARY](DOC/GUIDES/GLOSSARY.md)
- [INSTALLATION_FLOW](DOC/GUIDES/INSTALLATION_FLOW.md)
- [MEMORY_MAP](DOC/GUIDES/MEMORY/MEMORY_MAP.md)
- [OPERATORS_GUIDE](DOC/GUIDES/OPERATORS_GUIDE.md)
- [REF](DOC/GUIDES/REF.md)
- [RELEASES](DOC/GUIDES/RELEASES.md)
- [RELEASE_APPLICATIONS](DOC/GUIDES/RELEASE_APPLICATIONS.md)
- [TECHNICAL_GUIDE](DOC/GUIDES/TECHNICAL_GUIDE.md)

Included manuals work offline. References to source files or historical material
outside this package are explicit GitHub links pinned to the source commit
or release tag; they require those references to be published. Dated qualification records and
historical board cards are preserved unchanged; raw-log references require
the original repository. Start with README.md for this release identity.
