# ASM Address Practices

This is the quick operator guide for choosing addresses while using ASM,
`SEAL`, `PACKAGE`, `INSTALL`, `LOAD`, and HIMON `AP`. The main rule is:
package addresses, body addresses, flash storage addresses, and run addresses
are different roles even when the same four hex digits sometimes appear.
The historical Bank-0 assignments are preserved in
[SAMPLES/OLD/bank0-ap-entry-points.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/SAMPLES/OLD/bank0-ap-entry-points.md).
That ledger is not a split-V1 operator path: its installer and banked AP
staging dependencies were archived on 2026-08-07.

Addresses below match the 2026-09-15 ASM-F2/HIMON `00.0915(2324)` release.
ASM ends at `$BB83` exclusive; HIMON ends at `$EDEA` exclusive. These are
private layout measurements, not additional ABI promises.

## The Short Model

```text
ASM source PC       where ASM emits the BODY bytes now
SEAL base/end       the frozen BODY span from the last clean END
PACKAGE addr        where an AP envelope is written as data
INSTALL addr        where that AP envelope is stored in visible flash
LOAD dest           where BODY bytes are copied/relocated in RAM
AP pkg addr         where HIMON reads the AP envelope from RAM/flash/bank
AP dest             where HIMON loads/runs the BODY in RAM
```

An AP envelope is not the executable body. It is a container holding seal,
relocation, export/import, and body sections. You can copy the envelope around
as data. You only get runnable code after `LOAD`, `RELOCATE`, or `AP` copies
the BODY to a RAM destination and applies relocation rows.

The short Deck Plan name for this container is an **AP Capsule (APC)**. Its
normal working route is the **AP Island Runway (AIR)**: Build Bay `$2000-$2FFF`,
Envelope Bay `$3000-$3FFF`, and Run/Tray Bay `$4000-$4FFF`. The Capsule Rule
applies: an APC stored in flash is data, not executing code.

## Prompt Ownership

```text
ASM>$hhhh:   source lines: ORG, labels, instructions, END
SEAL>        post-END commands: SEAL, RELOCATE, PACKAGE, LOAD, INSTALL, NEW, .
>            HIMON commands: D, G, L, #, STR8, AP
```

If `G`, `D`, or `AP` fails at `SEAL>`, exit with `.` first.

## Usual Addresses

```text
$2000-$2FFF  AIR Build Bay: source/body and fixed RAM transient island
$3000-$3FFF  AIR Envelope Bay: Bank 0 APC, then normal load/run space
$3123        useful non-page-aligned relocation proof destination
$3200        common RAM AP envelope/package buffer outside the bank 0 flow
$4000        recommended load/run address for movable session reporter AP
$4800        legacy fixed run address for asm-session-report-4800.a
$8000        visible flash ASM address; also bank-window address for banked AP
B0:$hhhh     Bank 0 ASM session reporter AP package store address
$9000        common banked AP package store address for smoke tests
$0200-$09FF  LRS Symbol Name Lane; later STR8 Worker Code Tray
$0A00-$19FF  LRS Fixup Name Lane; later STR8 Sector Staging Deck
$1A00-$1FFF  user-free low RAM; no v1.2 firmware/tool allocation
$5000-$6D6D  ASM Work Hold in the current map
$6D6E-$79FF  Safe Output Deck
$7A00-$7BFF  Volatile Output Deck / record transit
$7C00-$7DBF  foreground High Tool Overlay
$7DC0-$7DC7  HIMON AP-link scratch
$7DE9-$7DFF  STR8 Recovery State Capsule
$7E00-$7EFF  High Service Deck (HSD)
$7F00-$7FFF  I/O Bulkhead, do not use as ordinary RAM
$F000-$FFFF  STR8 protected top sector
```

For the compact Bank 0 flow, keep transient code and packageable BODY bytes in
`$2000-$2FFF` and write the one-sector envelope at `$3000-$3FFF`. The current
HIMON AP loader keeps `$2000-$4FFF` as its general BODY destination. It also
admits the dedicated transient-tool tray `$7000-$7BFF` for fixed tools such as
`APSTORE`; using that tray is terminal for the current ASM session. Flash ASM
may emit into the separate upper arena beginning at the map-reported workspace
end only while no such tool owns it.

## Planned Pure Overlay Coexistence

This is an agreed future contract, not the current HIMON behavior:

```text
$0A00-$19FF  flash-sector and banked AP source staging
$2000-$3FFF  AP BODY/helper load and return space
$4000-$400F  active pure-overlay header
$4010-$4FFF  active fixed-base overlay BODY
```

The current banked `AP` command may retain `$0A00-$19FF` as its staging deck,
then load the AP BODY wholly below `$4000`. The overlay itself can be loaded
directly into `$4000-$4FFF` through STR8's existing selectable 4K staging
destination. Once active, it owns that island; the same bytes cannot
simultaneously serve a flash-sector tool, reporter, or another AP destination.

A different source bank/sector does not move the overlay's execution address;
the BODY still begins at `$4010`. One active overlay may tail-chain to another,
but a normal returning overlay-to-overlay call needs a reload manager or a
second slot. An overlay may make a returning call to an AP helper loaded in
`$2000-$3FFF`, because that AP does not overwrite the overlay slot.

## Current AP Envelope Limit

The current `$1000` limit is on the complete serialized AP envelope, not on
ASM output in general and not on a separately reserved metadata block. The
package length is:

```text
$001F fixed package bytes (header, five tag/length16 headers, seal payload)
+ ($01 + 5 * relocation count)
+ serialized EXPORT payload length
+ serialized IMPORT payload length
+ sealed BODY length
```

Empty EXPORT and IMPORT payloads are one count byte each. With no relocations,
the minimum envelope overhead is therefore `$0022`, leaving at most `$0FDE` bytes
for BODY data. Imports, exports, and relocations reduce that BODY maximum.

`PACKAGE 3000` means "write the envelope beginning at RAM `$3000`." It does
not mean that the package is `$3000` bytes long. A maximum-size envelope there
occupies `$3000-$3FFF`. The `$1000` check is a current one-sector package and
installer policy; it is not imposed by the AP header's address field widths.

After an APC has been written at `$3000-$3FFF`, `$4000-$4FFF` is still a usable
Run/Tray Bay, but it has no automatic role. It may hold transient data, an AP
load destination, a sector tray, or a session reporter, but those uses must not
overlap. This is the Runway Rule. A separate source may begin with `ORG $4000`; adding
`ORG $4000` to a BODY that began at `$2000`, however, does not create a second
independent package segment. `SEAL` records one span from the initial PC
through the high-water PC, including the hole, so that span would already
exceed the current AP envelope limit.

ASM-F2's own high UDATA is not at `$4000`; it currently begins at `$5000`.
Moving UDATA down to `$4000` is possible only as a new map decision, and would
evict both reporter forms and the remaining lower AP load/transient island.

Practical larger-program options are to run a direct RAM transient without
packaging, split code/data into several APs, keep resources in disposable data
APs, or add a future multi-sector/segmented package format. Merely raising the
`$1000` constant would also require new package-buffer placement, multi-sector
Bank 0 staging/programming, discovery, loader checks, and board proof.

Current APMAN supports selectable one-sector AP carriers in Banks 0-2.
Those banks are not presumed empty: any one may hold a foreign/opaque image,
which AP tooling must identify and leave alone. Multi-sector AP Store objects
remain a separate tool/media workflow; ordinary `INSTALL package Bn` writes
one complete envelope in one sector. Compression is not a dependency.

Storage placement and execution placement are separate questions. Moving an
intact AP envelope to another RAM or flash address does not relocate its BODY;
the envelope is still data. At load time, AP copies the BODY to the requested
RAM destination and uses its relocation/import metadata to make that copy
runnable. A future split installed form could leave metadata in one catalog
location and place the BODY in a suitable flash hole, but that would be a new
storage contract: the metadata must name and authenticate the external BODY,
and the loader must fetch it before applying relocation. A bare BODY copied out
of its envelope has not thereby become independently movable.

## Source Lifecycle Names

Sample names containing `-transient-$hhhh.a` are normally fixed-address RAM
programs: paste them, leave ASM, run them with `G hhhh`, and discard them.
Archived `OLD/bank0ap-put-transient-2000.a` retains the historical fixed-load
Bank-0 installer implementation, but split V1 cannot run its `$F003` modes
`$05/$06`. Other sources with `ENTRY` are AP-capable. The legacy `$4800`
reporter is fixed-load; `asm-session-report-v1.2-ap-2000.a` self-relocates its
complete internal body when supplied through a compatible source path.

## RAM Package Recipe

Use this when you want to assemble a body, make an AP envelope in RAM, load it
somewhere else in RAM, and run it.

```text
>ASM NEW
ASM>$2000: ORG $2000
ASM>$2000: MAIN ...body...
ASM>$hhhh: ENTRY MAIN        required to run; may be any BODY offset in AP v2
ASM>$hhhh: END
ASM OK
SEAL> SEAL
SEAL OK
SEAL> PACKAGE 3200
PKG OK @=$3200 L=$llll
SEAL> LOAD 3200 3000
LOAD OK=$3000 L=$bbbb C=$rr
SEAL> .
ASM BYE
>G 3000
```

In that recipe, `$3200` is the AP envelope address. `$3000` is the relocated
BODY address. They are not interchangeable.

## Visible Flash Install Recipe

Use this when the AP envelope should live in the currently visible low-flash
window and be reloadable later.

```text
SEAL> PACKAGE 3200
SEAL> INSTALL 3200
INST @=$hhhh L=$llll
SEAL> INSTALL 3200 hhhh
INST @=$hhhh L=$llll
SEAL> .
```

`INSTALL 3200` only suggests an erased flash hole. It does not write. Use the
printed `$hhhh` in `INSTALL 3200 hhhh` to write the unchanged AP envelope.

Later, from HIMON:

```text
>AP $hhhh $3000
```

Here `$hhhh` is the installed AP envelope source address. `$3000` is the RAM
load/run destination.

## Banked AP Recipe

Status: current operator workflow. Bank Maintenance `P` consumes an AP v2
envelope at `$7000` in the menu+top image (or `$4000` in the standalone image),
accepts a Bank 0-2 sector-base target, refuses configured work/backup roles,
requires the complete package destination to be erased, and programs through
its embedded mutation worker. The old standalone writer remains archived at
`SAMPLES/OLD/bankput-transient-3000.a` and must not be used.

```text
>ASM NEW
ASM>$2000: ...AP body source...
ASM>$hhhh: END
ASM OK
SEAL> SEAL
SEAL> PACKAGE ENTRYNAME $7000
PKG OK @=$7000 L=$00ll
SEAL> .
ASM BYE
>STR8
  confirm entry to STR8-N
STR8-N>L
  send STR8-N/BUILD/v1.34/s19/str8n-v1.34-bank-maint-menu-2000.s19
  STR8-N executes its validated S9=$2000 entry
BM> P
TYPE PUT BnS000 (n=0-2,S=8-F)> PUT B28000
 OK
BM> Q
```

After a cold boot into HIMON, run the banked package:

```text
>AP B2 $8000 $4000
```

In `AP B2 $8000 $4000`, `$8000` is the AP envelope address in bank 2's flash
window, and `$4000` is the RAM destination/run address. The body is loaded,
relocated, and executed from RAM; it does not execute from banked flash.

Keep `$7000` unchanged between `PACKAGE` and the completed Bank Maintenance
`P`. Do not run `AP`, `LOAD`, or another `PACKAGE` in that interval.

For the current board sequence, use
[PIA_LED_BANKED_AP_CARD.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/PIA_LED_BANKED_AP_CARD.md).
For the architectural and operational boundary between this raw carrier and
managed AP Store objects, use
[BANKED_AP_CARRIER_VS_AP_STORE.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/BANKED_AP_CARRIER_VS_AP_STORE.md).

## Bank 0 AP Install

Status: historical workflow, invalid on split V1. The source now lives at
`SAMPLES/OLD/bank0ap-put-transient-2000.a`. For current named carriers, use
APMAN `INSTALL package B0` with a suitable destination, or the current
Bank Maintenance path above within its narrower package limits.

The archived source was both a direct `G 2000` RAM tool and a
fixed-load AP package. It consumes the target AP envelope at `$3000`, stages
the selected Bank-0 sector at `$0A00-$19FF`, validates the staged package,
asks for exact `YES`, then programs and verifies the sector. Its required AP
load address is `$2000`.

Bootstrap the installer once by assembling that file at `$2000`, packaging it
at `$3000`, then running its still-present BODY directly with `G 2000`.
Record its actual `PKG OK` length and the Bank-0 address printed by the
installer as `PUTPKG`. The appendable installer has internal relocations but
must remain within HIMON's `$10` relocation-row limit.

During assembly, the LRS holds its Symbol and Fixup Name Lanes. Starting the
STR8 worker reloads the Worker Code Tray at `$0200` and reuses the SSD at
`$0A00-$19FF`. This is the Switchyard Rule: it intentionally ends the
reportable ASM session after `PACKAGE` has serialized the APC metadata.

```text
>ASM NEW
historical: paste DOC/GUIDES/ASM/SAMPLES/OLD/bank0ap-put-transient-2000.a
ASM OK
SEAL> PACKAGE 3000
PKG OK @=$3000 L=$hhhh
SEAL> .
ASM BYE
>G 2000
```

At the `DST` prompt, enter a bank 0 address such as `$8000`, or press Enter to
append after the last framed `AP/01` envelope in the first sector whose clean
erased tail can hold the new envelope. It does not reuse an interior `$FF`
run, and it never crosses a 4K sector boundary. At the confirmation prompt,
type exact `YES`. On success, `$7C00=$AC`, `$7C01/$7C02` hold the selected package address, and
`$7C06=00`. It also clears `$7C06` on abort or failure.

For every later target, assemble the target BODY, create its envelope at
`$3000`, exit ASM, and load the resident installer at its required `$2000`
address:

```text
SEAL> PACKAGE 3000
SEAL> .
ASM BYE
>AP B0 PUTPKG $2000
```

In that command, `PUTPKG` is where the installer envelope is stored in Bank 0.
`$2000` is where HIMON loads and runs the installer BODY. Neither operand is
the new target's flash address; the installer asks for that address at its
`DST` prompt, or chooses the first verified clean append tail when Enter is
pressed.

The archived hand-held board card uses fixture
`DOC/GUIDES/ASM/SAMPLES/OLD/bank0ap-print-smoke.a`, packages it at `$3000`,
stores it in bank 0 at `$8000`, and expects the AP body to print `B0 AP RUN`.

`SAMPLES/OLD/old-bank0ap-stage-transient-2000.a` and
`SAMPLES/OLD/old-bank0ap-commit-transient-2000.a` remain available for
diagnosing the staged sector or separating the irreversible write from the
selection pass. They are not the normal operator path.

## Movable Session Reporter

The preferred reporter source is
`asm-session-report-v1.2-ap-2000.a`. Its AP identity/entry is `ASMREPORT`, its body is `$0E21`,
and its expected package is `$0E4D`. It accepts AP destinations
`$2000-$41DF`; `$4000` is recommended and occupies `$4000-$4E20`.

The reporter has one ordinary AP relocation, then applies its own 238-row
private table to every remaining internal address. This makes the whole body
load-address relocatable despite ASM's 64-row ordinary relocation limit. It
is still ASM-map-matched because it reads current ASM-F2 tables and calls
current ASM-F2 output helpers. Rebuild and reinstall it after an ASM code or
map change.

Build its envelope with `PACKAGE ASMREPORT $3000`. For RAM use, preload with
`LOAD 3000 4000` at `SEAL>` before exiting and starting the target session.
For persistent storage with a provisioned APMAN carrier, use
`INSTALL 3000 B1`; `$4000` remains its RAM load/run address.

Load the stored reporter before the ASM session you want to inspect:

```text
>AP B1 ASMREPORT $4000
>ASM NEW
...assemble the target session...
SEAL> .
ASM BYE
>G 4000
```

The initial `AP` also runs the reporter once; that preliminary report may be
ignored. Its important job is to leave the patched reporter resident before
the target session begins. If the target session fails before `END`, exit
source mode with `.` and use `G 4000`.

The older `SAMPLES/OLD/asm-session-report-4800.a` remains available for a board that
already stores it. That form must be loaded and later rerun at exactly `$4800`.
Do not cold boot, warm boot, reload the reporter, start another session, run a
banked `AP`, or invoke a flash worker first. Those operations overwrite state
or reuse the low-RAM symbol/fixup name pools.

## Best Practices

- Use `$2000` for RAM transients and small sealed bodies unless the sample says
  otherwise.
- Use `$3200` for ordinary RAM AP envelopes and `$3000` for Bank 0 install.
- Use `$3000` as the default load/run destination for ordinary AP tests.
- Use `$3123` when you deliberately want to prove relocation across an odd
  page offset.
- Use `INSTALL 3200` as an address finder, then copy its printed address into
  `INSTALL 3200 hhhh`.
- Do not install into visible `$8000-$BFFF` unless you mean to overwrite the
  flash ASM image. Prefer the suggested erased hole or a banked AP install.
- Use bank 2 first for destructive banked AP storage tests.
- Use `$` on literal hex addresses in ASM and `SEAL>` commands.
- Keep `PACKAGE` buffers, `LOAD` destinations, and status bytes separate.
- Dump `$7C00` after v1.2 board-buildable installers; `$AC` is the usual success
  byte for these samples.
- Run HIMON `D`, `G`, and `AP` only from the `>` prompt.

## Common Mistakes

```text
PACKAGE 3200 then G 3200
```

Wrong: `$3200` is an AP envelope, not the relocated body.

```text
INSTALL 3200 then assume flash was written
```

Wrong: one-argument `INSTALL` is advisory. Use the two-argument form to write.

```text
AP B1 ASMREPORT $4800 for the movable session reporter
```

`$4800` was the legacy fixed reporter's address. It is outside the current
movable reporter's legal destination range; use its recommended destination:

```text
AP B1 ASMREPORT $4000
```

```text
LOAD 3200 3200
```

Usually wrong: the package source and body destination overlap.

```text
ORG $5000
```

Wrong under flash ASM: `$5000-$6D6D` is protected ASM workspace. The upper
emission arena begins at `$6D6E`; its availability still depends on other
active tools and HIMON's documented volatile ranges.

```text
Run reporter after reset or flash reinstall
```

Wrong for session inspection: those actions destroy or replace the live session
state the reporter is meant to read.
