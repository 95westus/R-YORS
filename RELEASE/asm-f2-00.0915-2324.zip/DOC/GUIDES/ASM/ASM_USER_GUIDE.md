# ASM User Guide

The stable HIMON service-vector/RAM-card and AP v2 package interfaces are
defined in [ASM_ABI_V1.md](ASM_ABI_V1.md). Internal ASM addresses are not part
of that ABI.

Status: current operator guide for the 2026-09-15 release, ASM-F2
`00.0915(2324)` with HIMON `00.0915(2324)` and STR8-N 1.34. The release
differs only in timestamp strings from the physical-reset-qualified board
pair ASM-F2 `00.0915(2243)` / HIMON `00.0915(2233)`; the new stamp was not
reflashed. ASM occupies 15,235 bytes at `$8000-$BB82`, with end `$BB83`
exclusive and 1,149 bytes free below `$C000`. Application qualification is
separate; see [the release application catalog](../RELEASE_APPLICATIONS.md).
ASM is an onboard W65C02 workbench. The hardware proof source of truth remains
[TEST_PLAN.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/TEST_PLAN.md). For WDC, ca65, and vasm translation, including
the non-equivalent AP metadata model, see
[ASM_DIALECT_CROSSWALK.md](ASM_DIALECT_CROSSWALK.md).

## What ASM Is

ASM is the flash-resident onboard assembler entered from HIMON as `ASM`.
It reads ordinary source lines, emits native W65C02 bytes into RAM, resolves
forward references at `END`, and then opens a small `SEAL>` command window for
relocation/package work.

The current flash image is loaded at `$8000` and enters through the HIMON
FNV/RJOIN catalog. It starts new source sessions at `$2000` unless source uses
`ORG`.

For the short operator view of which address belongs to which command, see
[ADDRESS_PRACTICES.md](ADDRESS_PRACTICES.md).
For the historical Bank-0 package ledger and exact AP entry meanings, see
[SAMPLES/OLD/bank0-ap-entry-points.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/SAMPLES/OLD/bank0-ap-entry-points.md).
Its install/run workflow is archived and is not valid on split V1.

## Current Operational Process

The movable-package lifecycle is named `SPILL`:

```text
SEAL     freeze/check facts
PACK     emit AP envelope; current command spelling is PACKAGE
INSTALL  store AP envelope
LOAD     read AP and relocate BODY into RAM
LINK     future import binding in the loaded overlay/temp-RAM image
```

Current flash ASM implements `SPIL`: `SEAL`, `PACKAGE`, `INSTALL`, and `LOAD`.
`LOAD` already binds supported resident imports through HIMON. There is no
separate interactive `LINK` command. A loaded BODY runs through HIMON `G`;
HIMON `AP` combines package load/link/entry execution, and `AP L` stops after
load/link.

Build the current board artifacts on the host:

```text
make -C SRC all
make -C SRC asm-session-report
```

`make -C SRC all` creates a development image with ASM-F2 in low flash.
For the reviewed release, use the versioned archives in `RELEASE/`, their
manifests and `QUALIFICATION.json`; rebuilding can change the visible stamp.
Bank 3 does not carry the ASM session reporter AP. Build/load that reporter
separately, or store it with APMAN in a deliberately selected Bank 0-2 sector.
The preferred movable form uses `$4000` as its conventional RAM destination:

```text
AP B1 ASMREPORT $4000
```

Some current board-ingested files still live under
`DOC/GUIDES/ASM/SAMPLES/` because the present ASM-F2 workflow pastes or
packages them directly. Treat the paths named in this guide as current until a
replacement is documented; retired samples and proof-only sources move by the
plan in [../PLANNING/HISTORICAL_CODE_MIGRATION_PLAN.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/PLANNING/HISTORICAL_CODE_MIGRATION_PLAN.md).
The Life16 bank-2 cards are historical pre-split-worker evidence, not current
installation instructions. The HIMON release includes the independent
standalone Life program and its notice; see the release application catalog.

After STR8-N installation, use `C` to cold-enter HIMON; ASM-F2 is at `$8000`. If
you will need a session report, load the reporter AP before starting that ASM
session. Exit the session with `.`, then rerun the RAM copy with `G 4000`:

```text
AP B1 ASMREPORT $4000
ASM NEW
...target source...
.
G 4000
```

For an older board image or a narrow development pass, update HIMON through
STR8-N `I` when needed, then return with `W` or `C`. Load the optional external
reporter first if table detail will be needed later:

```text
L              send SRC/BUILD/s19/asm-session-report-v1.2-7000.s19
```

Install flash-resident ASM into an already-enrolled Bank 3 through STR8-N:

```text
>STR8          confirm entry
               select S at the boot selector
STR8-N>I
B0-3: 3
RANGE: 8-B
I B3 8-B WRITE? Y: Y
S19            send FIRMWARE/ryors-v1.2-asm-bank3-8-b.s19 from the ASM-F2 ZIP
...COMMIT? Y: Y
OK
STR8-N>C
```

The ASM-only stream covers exactly `$8000-$BFFF`; its S9 `$FFFF` preserves
the existing Bank-3 HIMON entry, so it is not a first-install image. Use
`FIRMWARE/ryors-v1.2-himon-asm-bank3-8-e.s19` with range `8-E` and S9 `$C000`
for first enrollment or an interrupted Bank-3 transaction. Both archives
include that recovery stream. Sector F remains owned by STR8-N.
The public service-vector addresses remain fixed, but their pointed-to
routine addresses are map-dependent; do not reuse an old raw pointer dump
as a compatibility test.

The prompt text below shows where each line is typed; do not paste the prompt
characters. A normal assemble, package, install, load, and run session looks
like this RAM-only example:

```text
>ASM NEW
ASM>$2000: ORG $2000
ASM>$2000: START LDA #$5A
ASM>$2002: RTS
ASM>$2003: ENTRY START
ASM>$2003: END
SEAL> PACKAGE START 3200
SEAL> LOAD 3200 3000
SEAL> .
>D 3000 3002
>G 3000
```

For persistent named storage with a provisioned APMAN carrier, use
`INSTALL 3200 B1` before leaving `SEAL>`, then `AP B1 START` from HIMON.
Choose the bank deliberately: the bank token confirms the write. APMAN
selects an erased, unreserved carrier sector. `INSTALL pkg` alone remains
advisory; the visible-flash form `INSTALL pkg flash_addr` is a separate
operation described below and consumes space in Bank-3 low flash.

## Return Status

Runnable ASM samples use one top-level return convention:

```text
C=1  success; A=$00 or the sample's documented success status
C=0  failure/abort; A=the documented nonzero status
```

HIMON captures flags immediately after a `G` or `AP` target returns, so the
`RET ... C`/`RET ... c` display is authoritative. Internal subroutines may use
carry for their own contracts; only the executable's final exit sets the
top-level result.

ASM-F2 keeps a nonzero result sticky for the active session. Typing `.` after
any assembly, seal, package, load, install, or input failure returns `C=0` and
that status in A. A clean session returns `C=1,A=$00`. Successful `ASM NEW` or
`NEW` starts a fresh result. Because `ASM` is an FNV command rather than a
direct `G`, HIMON renders its failed return as
`#56AD7400# EXEC ERR=$hh` instead of a `RET` line.

To load an already-installed package later, enter an empty source session just
to reach `SEAL>`:

```text
>ASM NEW
ASM>$2000: END
SEAL> LOAD hhhh 3800
SEAL> .
>G 3800
```

Prompt ownership matters:

```text
ASM>$hhhh:   source lines only
SEAL>        SEAL, RELOCATE, PACKAGE, LOAD, INSTALL, NEW, .
>            HIMON commands such as D, G, L, #, STR8
```

Numeric operands at `SEAL>` are hexadecimal by default, matching HIMON: type
`3000`, `BABB`, or `FF` without a prefix. The older `$3000` spelling remains
accepted for compatibility. This rule applies only to post-`END` commands;
ordinary `ASM>` source keeps its existing `$`-prefixed hexadecimal syntax.
Entry identities such as `START` or `ASMREPORT` remain symbolic operands.
An identity made only from one to four hex digits (`FACE`, for example) is
therefore numeric at `SEAL>` and should be renamed.

Alphabetic input at `SEAL>` is folded and echoed uppercase before byte-exact
command matching. Thus `seal` appears and executes as `SEAL`; the command set
remains `SEAL`, `RELOCATE`, `PACKAGE`, `LOAD`, `INSTALL`, `CHECK` (when built),
and `NEW`. Source entry at `ASM>$hhhh:` remains case-preserving. The punctuation
command `.` is unchanged.

For example, `D 3800 FF` at `SEAL>` reports `ERR OPERAND`; exit with `.` and run
the dump at HIMON's `>` prompt.

## Starting And Leaving

From HIMON:

```text
ASM
```

Expected entry:

```text
ASM-F2
ASM>$2000:
```

The source prompt is:

```text
ASM>$hhhh:
```

`$hhhh` is the current assembler PC before the next accepted source line.
Accepted source lines are quiet. Rejected source lines print:

```text
ERR reason PC=$hhhh
```

While still in source mode, `.P` prints the current PC without assembling:

```text
.P
```

Exit either source mode or `SEAL>` with:

```text
.
```

The flash wrapper prints `ASM BYE` and returns to HIMON.

Leaving `SEAL>` does not discard the completed session. To run another seal,
package, load, or install command against the same frozen post-`END` facts,
re-enter from the HIMON prompt with:

```text
ASM SEAL
```

The wrapper prints its ASM-F2 banner and returns directly to `SEAL>`. It also
clears a sticky wrapper result left by an earlier rejected SEAL command. If no
completed session is preserved, `ASM SEAL` fails closed with HIMON
`EXEC ERR=$03`. Bare `ASM` and `ASM NEW` still begin a new `$2000` source
session and deliberately discard the old post-`END` window.

## Quick Example

Paste or type the source lines after entering `ASM`; do not include the prompt
text:

```asm
ORG $2000
LDA #$5A
STA $7100
RTS
END
.
```

After returning to HIMON:

```text
G 2000
D 7100
```

The run should return with `A=5A`, and `$7100` should contain `$5A`.

## Source Lines

V1 source shape:

```text
[label[:]] operation [operand]
```

Rules:

- One physical line is one source line.
- The line limit is 63 visible characters.
- Spaces and tabs are whitespace; tabs have no column meaning.
- `;` starts a comment outside character quotes.
- Empty and comment-only lines are accepted.
- Tokens fold to uppercase outside quotes.
- Character quotes preserve exact byte value.
- A label colon is optional.

Good shapes:

```asm
MAIN LDA #$5A
MAIN: LDA #$5A
LOOP
LOOP:
COUNT EQU 10
BUF DS COUNT,$AA,$55
```

Rejected shapes:

```asm
LABEL ORG $2000
LABEL END
EQU $12
ORG
END X
LDA #1 EXTRA
```

## Labels

Global symbols may use:

```text
A-Z 0-9 _
```

Global symbols must not begin with a digit, and must not collide with
mnemonics, directives, or register names. `A`, `X`, and `Y` are reserved.
Current global symbol text is capped at 31 visible characters.

Labels bind the current PC before emitting the rest of the line:

```asm
MAIN JSR TARGET
TARGET RTS
```

## Local Labels

Local labels are scoped under the most recent nonlocal PC label.

Accepted local spellings:

```text
.NAME
.NAME:
?NAME
?NAME:
```

Local names are label-only helpers. They cannot be `EQU` symbols and cannot be
`EXPORT` or `IMPORT` names. Current limit is 16 local label rows per active
global scope, with 15 visible characters per local name including the prefix.

Example:

```asm
ORG $2000
MAIN LDX #$03
.LOOP DEX
BNE .LOOP
RTS
END
.
```

A local label before any nonlocal PC label is `BAD SYM`.

## Literals And Expressions

Literal forms:

```text
123          decimal
$FF          hexadecimal
$00F0        hexadecimal with absolute-width source intent
%10101010    binary
%XXXXXXX1    binary mask/pattern
'A'          character byte
'''          single quote character
*            current assembler PC
```

Expressions are simple left-to-right infix:

```text
term { op term }*
```

Operators:

```text
+ - | & ^ << >>
```

Evaluation is strictly left to right; shifts have no precedence advantage.

Selectors:

```text
<expr         low byte
>expr         high byte
```

A forward reference may contain one unresolved symbol plus a signed byte
addend (`-128` through `+127`):

```asm
LDA TABLE+1
BNE TARGET-2
DW TABLE+2
LDA #<TABLE+1
LDX #>TABLE+1
```

For selectors, addition happens before byte selection: `#>TABLE+1` includes
any carry out of the adjusted low byte. The same encoding is retained for a
declared import when an AP v2 package is loaded. Two unresolved symbols,
logical or shift operators on an unresolved value, reversed subtraction, and
addends outside the signed-byte range are rejected. Resolved expressions keep
the general left-to-right operator rules above.

V1 does not support grouping parentheses or forward `EQU` dependencies.

## Address Width

Source spelling controls address width. ASM does not silently choose zero page
because a value is small.

```asm
LDA $12       ; zero page
LDA $0012     ; absolute

ZPFOO EQU $12
ABSFOO EQU $0012
LDA ZPFOO     ; zero page
LDA ABSFOO    ; absolute
```

Decimal numbers are concrete values. They are valid for immediates, bit
numbers, counts, and data, but not as memory-address operands:

```asm
LDA #13       ; OK
LDA 13        ; ERR SIZE
```

Do not assume hosted-assembler behavior here. ASM-F2 width follows spelling,
expressions evaluate strictly left to right, and its forward-reference and
relocation tables are bounded independently. The concise porting rules and
directive equivalents are in
[ASM_DIALECT_CROSSWALK.md](ASM_DIALECT_CROSSWALK.md).

## Directives

Current v1 directives:

```text
EQU
DB
DW
DS
ORG
END
ENTRY
EXPORT
IMPORT
DC
```

`EQU` defines a resolved value now:

```asm
COUNT EQU 10
ADDR  EQU $2000
LOW   EQU <ADDR
```

`DB` emits byte data. If an item is word-width, `DB` emits the word in little
endian order; use `<` and `>` when one byte is intended:

```asm
DB $12,$34,'A'
DB <ADDR,>ADDR
```

`DC` accepts a compact single-quoted family:

```asm
DC 'text'         ; raw bytes, no terminator
DC C'text'        ; trailing-zero C string
DC H'text'        ; high bit set on the final character
DC P'text'        ; one-byte length followed by text
```

The older comma/double-quote forms remain source-compatible:

```asm
DC C,"text"       ; trailing zero C string
DC HB,"text"      ; high bit set on the final character
DC P,"text"       ; one-byte length followed by text
```

Empty raw text emits no bytes; empty CSTR, HBSTR, and PSTR forms emit `$00`,
`$80`, and `$00`. Raw and HB strings may contain at most 255 characters;
CSTR and PSTR forms may contain at most 254 because their terminator/prefix
must fit the same 255-byte atomic emission. A semicolon after the closing
quote starts a comment. Apostrophes cannot currently be escaped inside a
single-quoted string, so embedded or unterminated quotes fail atomically with
`ERR OPERAND`. Single-character expressions such as `DB 'A'` and `LDA #'A'`
retain their existing meaning outside `DC`.

`DW` emits each expression as a 16-bit little-endian word. A forward label is
patched when it binds and consumes a forward-fixup row in the meantime:

```asm
DW START,TARGET,$1234
```

`DS count` advances the PC without initializing bytes. `DS count, init-list`
emits exactly `count` bytes by repeating or truncating the initializer list:

```asm
DS 3
DS 5,$AA,$55
```

Important seal rule: ordinary ASM accepts forward `ORG` gaps and plain
`DS count`, but `SEAL` rejects bodies with holes or unowned bytes. Use a single
contiguous body and initialized `DS` when the result should be sealable.

`ORG expr` sets the assembler PC. It emits no bytes and cannot move backward:

```asm
ORG $2000
```

`END` closes the source session, resolves required fixups, prints the tables,
and enters `SEAL>` on success.

`ENTRY name` records a defined global PC label as the package entry name using
the same compact public export row as `EXPORT name` in this size-first slice.
Use `ENTRY name` instead of also exporting the same name.

`EXPORT name` records a defined global PC label as public package metadata.
`IMPORT name` declares an external symbol as intentional package metadata and
forces matching operands to become import relocation rows.

Plain English:

```text
ENTRY   this is the package front door
EXPORT  this package provides this global label for outside callers
IMPORT  this package needs this global label from outside providers
```

Export only the intended public contract. Do not export every helper routine.
For a normal AP program, `ENTRY MAIN` is usually the one public row needed.

`START` is not reserved; it is available as an ordinary label.

## Instructions

Use ordinary W65C02 mnemonics implemented by the current ASM opcode table.
Unsupported mnemonics report `ERR UNKNOWN OP`; unsupported addressing combinations
report `ERR ADDR MODE` or `ERR SIZE`.

Bit operations use the base mnemonic plus an explicit bit number:

```asm
RMB 3,$12
SMB 7,$12
BBR 3,$12,TARGET
BBS 7,$12,TARGET
```

Do not write `RMB3` or `BBS7`.

Direct `JSR name` and `JMP name` first check the current session. If the name
is not a session symbol and it is resident in the running HIMON/RJOIN catalog,
ASM can emit the resident address directly. Declaring `IMPORT name` first
forces deferred import metadata instead.

The difference is binding time:

```asm
JSR BIO_FTDI_PUT_CSTR
```

With no `IMPORT`, ASM asks the running HIMON/RJOIN catalog for the address now
and writes that concrete address into the emitted body. The package carries no
import row for that call. Use this for a proof or body that is intentionally
tied to the current resident image.

```asm
IMPORT BIO_FTDI_PUT_CSTR
JSR BIO_FTDI_PUT_CSTR
```

With `IMPORT`, ASM leaves placeholder bytes in the body, writes import metadata,
and records import relocation rows. HIMON/STR8/OIL resolves the name through the
resident RJOIN catalog when the AP package is loaded, then patches the loaded
RAM body. Use this when the package should stay movable and bind to whichever
resident image loads it later. This costs one import slot and one relocation row
for each patched address use.

## END Versus SEAL

`END` finalizes assembly. It resolves required fixups, freezes the body facts,
prints the assembly result, and switches to:

```text
SEAL>
```

`SEAL>` is not source mode. It accepts only the wrapper commands below.
Before a clean `END`, those same words are ordinary source words and will not
run the post-session command.

## SEAL Commands

`SEAL` validates the frozen body facts and prints record summaries:

```text
SEAL
```

Success shape:

```text
SEAL OK FLAGS=$01 BASE=$hhhh END=$hhhh
SEAL REC @=$hhhh LEN=$hhhh FNV=$hhhhhhhh
SEAL REL @=$hhhh COUNT=$nn
```

If exports or imports exist, `SEAL` also prints `SEAL EXP` and/or `SEAL IMP`.

The default flash image omits the older interactive `RESOLVE` command. Import
metadata can still be packaged. In the combined HIMON/STR8 image, `LOAD` and
HIMON `AP` resolve declared imports that name resident RJOIN symbols through
HIMON's resident AP linker; missing or non-resident imports still fail with
`LOAD FIXUP` (status `$09`). The current AP service doorway is HIMON's published pointer at
`$7E2D-$7E2E`. STR8-N `$F006` queries its raw console ABI; it is not an AP
linker entry.

`RELOCATE address` copies the frozen body to a RAM destination and applies
internal relocation rows there:

```text
RELOCATE 3000
```

Success shape:

```text
REL OK BASE=$3000 C=$nn
```

`RELOCATE` does not resolve import rows.

`PACKAGE address` writes an AP v2 package envelope to RAM. Runnable packages
may also use `PACKAGE identity address`, where `identity` must be the unique
name declared by `ENTRY`:

```text
PACKAGE 3200
PACKAGE ASMREPORT 3200
```

Success shape:

```text
PKG OK @=$3200 L=$hhhh
```

The envelope layout is:

```text
AP header
S tag + length16 + seal payload
R tag + length16 + relocation payload
E tag + length16 + typed export rows
I tag + length16 + typed import rows
B tag + length16 + body bytes
```

AP v2 is the only accepted version. Export rows carry kind/flags, body offset,
FNV32, name length, and PACK40 text. Import rows carry the same kind contract,
FNV32, name length, and PACK40 text. `ENTRY` marks at most one executable
export. Import binding requires the resident target's executable/data contract
to match.

The unique executable `ENTRY` row is also the runnable package identity; AP v2
does not duplicate it in another header field. The named `PACKAGE` form checks
the complete canonical symbol text, case-insensitively, before writing the
envelope. Hashes are accelerators, not sole identity proof. The one-argument
form remains valid for compatibility.

`MODULE name` is reserved for a future non-runnable/library package identity.
It is not accepted source syntax yet. That future directive is intended for
packages with exports but no executable `ENTRY`; it will require an explicit
AP identity representation rather than overloading an arbitrary export.

`PACKAGE` self-verifies the written BODY FNV before reporting success. It does
not install to flash, resolve imports, relocate the body, or run code. The AP
envelope can be copied as data; executing its BODY at a new address requires a
relocation/load step.

`LOAD pkg dest` reads an AP v2 envelope from RAM or currently visible flash,
copies the BODY to RAM, applies internal relocation rows, and resolves resident
RJOIN import rows through the resident HIMON AP service:

```text
LOAD 3200 3000
```

`LOAD` is a post-`END` `SEAL>` command, not an ASM source line. To load an
already-installed flash package without assembling new code, open an empty
session and immediately end it:

```text
>ASM NEW
ASM>$2000: END
SEAL> LOAD hhhh 3800
SEAL> .
>G 3800
```

Success shape:

```text
LOAD OK=$3000 L=$hhhh C=$nn
```

The general destination BODY span must fit wholly in `$2000-$4FFF`. The
resident service also reserves `$7000-$7BFF` for fixed transient tools such as
`APSTORE`; that overlay destroys the live ASM upper arena and is therefore
terminal for the session. `LOAD` validates the complete AP v2 structure and
BODY FNV before patching. Resident imports are
linked through RJOIN; missing imports, kind mismatches, non-resident
dependencies, and unsupported relocation rows fail with
`LOAD FIXUP`. A RAM package may be above or below its destination,
but the complete envelope and destination BODY ranges must not overlap.

The one-argument `INSTALL pkg` form is read-only advisory:

```text
INSTALL 3200
```

Success shape:

```text
INST @=$hhhh L=$hhhh
```

It parses enough AP header/length information to find the first erased
contiguous visible flash hole in `$8000-$FEFF` large enough for the whole
envelope. `INSTALL pkg flash_addr` writes the unchanged AP envelope to an erased
visible low-flash hole through HIMON's install service. Numeric operands use
the same bare hexadecimal convention as HIMON:

```text
INSTALL 3200 hhhh
```

The normal banked-carrier install form is:

```text
INSTALL 3200 B1
```

The bank token is the in-command destructive confirmation. The APMAN carrier
manager validates an AP v2 envelope of at most `$1000` bytes, selects the first
completely erased and unreserved 4K sector in the requested Bank 0-2, programs
and verifies the full sector through the RAM worker, restores Bank 3, and
prints the exact selected address. There is one complete carrier per sector;
this is not AP Store record packing. The older Bank Maintenance `P` command
remains a recovery path for its `$00FF` package policy.

HIMON carrier forms are:

```text
APS
APS B1
APS B1 BANKAUDIT
AP B1 BANKAUDIT
AP B1 A000
AP L B1 BANKAUDIT
AP B1 BANKAUDIT 3000
```

`AP` executes; `AP L` only loads and fixes. Selection is by the package's
executable `ENTRY` name or by its sector-base address. The optional destination
overrides the sealed base. Duplicate names in one bank fail, while an address
disambiguates. APMAN V1 stays live at `$7000`, so manager-driven BODY loads
must fit in `$2000-$6FFF`; direct resident `AP package destination` remains the
recovery form.

That path copies the banked AP envelope into the sector staging buffer, loads
and links BODY bytes into a manager-approved destination in `$2000-$6FFF`,
and runs from the requested load address. APMAN itself owns `$7000-$7BFB`. It
never executes a carrier directly from banked flash.

A parent AP can use published direct LOAD operation `$01` through the service
pointer at `$7E2D-$7E2E` for a non-overlapping package already in RAM or
visible flash. Named banked-child chaining through manager operation `$04` is
mechanically possible but not yet a supported ABI: the parent must survive
staging, manager scratch, and the child destination, and no parent-context
contract has been board-proven. See [Banked AP Carrier Versus AP
Store](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/BANKED_AP_CARRIER_VS_AP_STORE.md).

Flash ASM keeps symbol names at `$0200-$09FF` and fixup names at
`$0A00-$19FF`. `PACKAGE` serializes the required AP metadata before those
tables are released. Any STR8 flash worker or banked `AP` operation then
reuses that low RAM, so run `asm-session-report` before staging if symbol and
fixup names from the current session are required.

For a current STR8-N top-sector update, load the standalone repository's
`BUILD/v1.34/s19/str8n-v1.34-top-update-2000.s19` through STR8-N `L`. It embeds
the exact manifest-checked top image, verifies a full B1:F backup, preserves
the live directory/configuration pocket, and requires exact confirmations
before B3:F erase. The former ASM transient writers are archived under
`DOC/GUIDES/ASM/SAMPLES/OLD/`; do not use them for an installed refresh.

`CHECK address` exists only in full-core or package-check diagnostic builds.
It is intentionally omitted from the default flash-resident ASM image to keep
space below `$C000`.

## External Session Report

Default flash ASM no longer prints `ASM TABLES` after `END`. Use the external
report proof when the live symbol/fixup/reloc tables are needed:

```text
make -C SRC all
make -C SRC asm-session-report
```

The current `make all` image does not store a reporter after ASM-F2. The
preferred generated source is `asm-session-report-v1.2-ap-2000.a`: its
identity/entry is `ASMREPORT`, it packages at `$3000`, can load anywhere from
`$2000-$41DF`, and conventionally uses
`$4000`. Its BODY is `$0E21` bytes and its AP envelope is `$0E4D` bytes.
If it is stored in Bank 1, load it before the session to inspect,
then exit that session with `.` and run the resident copy:

```text
AP B1 ASMREPORT $4000
ASM NEW
...target source...
.
G 4000
```

`make -C SRC asm-session-report` also builds the explicit reporter artifacts.
The host-built RAM reporter is `SRC/BUILD/s19/asm-session-report-v1.2-7000.s19`;
the matching fixed AP proof package is
`SRC/BUILD/bin/asm-session-report-v1.2-7000.ap.bin`.
Load it before the ASM session to inspect, then after `END` and `.` run
`G 7000`. This fixed `$7000` product is different from the movable `$4000`
reporter; do not load the fixed AP at `$4000`. Reserve the selected reporter's
RAM span while assembling the target session.
For flash ASM itself, `DOC/GUIDES/ASM/SAMPLES/asm-session-report-v1.2-ap-2000.a`
is a compact, pasteable `.a` source. It prints the split low-RAM pools, the
`$2000/$3000/$4000` islands, high UDATA, safe output, and volatile regions.
Its complete internal body self-relocates; its current ASM helper/table calls
remain map-matched. The legacy
`SAMPLES/OLD/asm-session-report-4800.a` historical fixed-load source and
`SAMPLES/OLD/asm-session-report-transient-7000.a` non-flash/runtime-paste
source are retained in the archive.

For a RAM session, assemble the movable reporter, `PACKAGE ASMREPORT 3000`,
then `LOAD 3000 4000` before leaving ASM. For optional persistent storage with
a provisioned APMAN carrier and suitable Bank-1 destination, use
`INSTALL 3000 B1` at `SEAL>`. Rebuild, repackage, and reinstall either reporter
after ASM-F2 code or map changes. A
version-stamp-only rebuild with unchanged addresses does not invalidate it.
Load the matching reporter before the session to inspect, because a banked
load reuses low RAM:

```text
AP B1 ASMREPORT $4000
ASM NEW
...target source...
.
G 4000
```

The `$4800` reporter is no longer an active build artifact. Its source and
board evidence remain historical. Current fixed host builds use `$7000`; the
movable `$4000` form remains preferred for stored use. A future optional ASM
entry may preload `ASMREPORT` at `$7000` before `ASM_BEGIN` and reserve its span
from that session's output range.

If `PACKAGE ASMREPORT 3000` reports `PKG INVALID`, regenerate the reporter source with
`make -C SRC asm-session-report`; older generated sources could assemble but
set bad seal flags by overflowing the AP relocation table.

`NEW` starts another source session at the frozen `END` PC:

```text
NEW
```

`NEW $addr` is rejected; use `ORG` in the new source session if a different
target is needed.

`.` exits to HIMON.

## Relocate And Package Example

Paste this at the ASM source prompt:

```asm
ORG $2000
MAIN JSR TARGET
LDA #<TARGET
LDX #>TARGET
TARGET RTS
END
```

Then at `SEAL>`:

```text
SEAL
RELOCATE 3000
PACKAGE 3200
LOAD 3200 3000
INSTALL 3200
.
```

Expected behavior:

- `SEAL` reports `BASE=$2000 END=$2008` and three relocation rows.
- `RELOCATE 3000` writes a runnable copy at `$3000`.
- `PACKAGE 3200` writes an AP v2 envelope whose body still contains the
  original `$2000`-based bytes.
- `LOAD 3200 3000` reloads the package BODY to `$3000` and applies the same
  internal relocation rows.
- `INSTALL 3200` suggests an erased visible flash hole but does not write it.

From HIMON:

```text
D 3000 3007
D 3200 3236
G 3000
```

For a fuller current-life-cycle proof with no imports, paste
`DOC/GUIDES/ASM/SAMPLES/OLD/spill-roundtrip-2000.a`. It exercises forward
references, a backward branch, export metadata, internal code relocation,
`PACKAGE`, `INSTALL`, `LOAD`, and `G`. Load it to non-page-aligned `$3123` so
both low and high relocation bytes have to move. After running `G 3123`,
`D 5848 50` should show `$5848=$AC`, `$5849=$00`, target pointers `$316E` at
`$584A-$584D`, loop pointer `$3144` at `$584E-$584F`, and `$5850=$5A`.

The relocated body should begin:

```text
20 07 30 A9 07 A2 30 60
```

## Import Metadata Example

Use `IMPORT` when the package should remember that an external name must be
resolved later:

```asm
ORG $2200
IMPORT EXT
MAIN JSR EXT
END
```

At `SEAL>`:

```text
SEAL
PACKAGE 3200
.
```

The body contains placeholder bytes for `EXT`, and the package contains an
import record. The current HIMON/STR8 AP loader can resolve imported names that
exist as resident RJOIN symbols, such as `BIO_FTDI_PUT_CSTR`. A made-up name
like `EXT` still fails at load/run time with status `$09` (`LOAD FIXUP` at
the ASM prompt).

## Memory Use

Current flash ASM default target:

```text
$2000        initial ASM source PC
```

Current practical map while ASM is running:

```text
$0200-$09FF  symbol-name pool; released when STR8 reloads its worker
$0A00-$19FF  fixup-name pool; released for flash sector staging
$2000-$2FFF  packageable ASM body/helper emission island
$3000-$3FFF  Bank 0 AP envelope, then AP load/run space
$4000-$4FFF  lower RAM output/load space
$5000-$6D6D  protected flash ASM UDATA in the current map
$6D6E-$7CFF  upper ASM output/scratch arena
$7E00-$7EFF  HIMON service and monitor workspace
$7F00-$7FFF  I/O, do not use
```

The flash wrapper rejects output into its protected UDATA span. `ORG $5000`
reports `ERR RANGE`; the current map permits `ORG $6D6E` through `$7CFF`.
Runtime code may still use ordinary RAM after leaving ASM if it does not depend
on returning to the same live ASM workspace. HIMON retains `$2000-$4FFF` for
general AP destinations and reserves `$7000-$7BFF` for terminal transient
tools; `$5000-$6FFF` and `$7C00-$7FFF` remain excluded.

Current proof-sized table limits:

```text
global symbols       128
fixups               128
relocation rows      64
exports              64
imports              64
report references    192
locals per scope     16
line length          63 visible chars
global name length   31 visible chars
local name length    15 visible chars including . or ?
```

ASM, AP v2 packaging, and the resident HIMON loader share a 64-row relocation
limit. An AP v2 relocation payload is `1 + 5*N` bytes, so 64 rows occupy
`$0141`; all section lengths are 16-bit. Exports and imports also have 64-row
limits. The overall envelope remains capped at 4 KiB, so all three tables can
reach their individual limits, but a package containing every maximum-length
name in every table may leave little or no room for BODY bytes.

Fixups and relocations are separate budgets. Each unresolved emitted use
consumes one of the 128 fixup rows, even when many rows name the same target.
Putting data and helpers before their fixed-load uses can therefore prevent
`ERR FIXUP`. It does not reduce the relocation rows required to move internal
absolute address sites. Relocation overflow leaves ordinary fixed-address ASM
valid but seal-ineligible; it does not become packageable when later AP work
is finished. See the worked distinction in
[ASM_DIALECT_CROSSWALK.md](ASM_DIALECT_CROSSWALK.md).

Global symbols use 128 metadata rows plus a bounded `$0800`-byte append-only
name pool. Names remain 1-31 characters, but consume only their actual length;
there is no 32-byte slot per symbol. Both the row limit and pool limit are
checked before commit, and line rollback restores the pool cursor.

The former AP v1/HIMON 50-row boundary remains historical hardware evidence.
AP v2 host/build and board gates pass, including all 64 relocation rows, all
64 export/import slots, typed import matching, named package identity, and the
relocated expression card. Exact evidence is tracked in
[TEST_PLAN.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/TEST_PLAN.md).

These are implementation limits, not permanent language promises.

The low-RAM split helped, but it did not automatically raise these row counts.
Flash ASM now keeps symbol names in `$0200-$09FF` and fixup names in
`$0A00-$19FF`, which frees the higher ASM workspace and gives STR8 a 4K sector
staging buffer after package metadata has been serialized. The current row
ceilings above are still deliberate constants. If they grow, grow
fixup/relocation capacity first, then symbol/local capacity, then
import/export slots.

## Error Messages and Return Codes

The accepted text-diagnostic image prints `ERR reason PC=$hhhh` for source errors.
Numeric values remain in the ASM return ABI (`C=0`, `A=status`); older board
images and retained transcripts still show `ERR=$ee` and abbreviated names.
See [TEST_PLAN.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/TEST_PLAN.md) for full-suite and board evidence, including
physical-reset recovery and post-reset ASM smoke.

| Status | Display reason | Meaning |
| --- | --- | --- |
| `$00` | `OK` | Success |
| `$01` | `UNKNOWN OP` | Unknown mnemonic/operation |
| `$02` | `DIRECTIVE` | Unsupported directive; reserved diagnostic |
| `$03` | `OPERAND` | Malformed, extra, or missing operand text |
| `$04` | `ADDR MODE` | Addressing mode unsupported by the mnemonic |
| `$05` | `SIZE` | Source width does not fit the instruction/context |
| `$06` | `RANGE` | Value, branch, ORG, or target outside its allowed range |
| `$07` | `LINE` | Malformed or too-long source line |
| `$08` | `NAME` | Invalid/duplicate/reserved/out-of-scope symbol, or symbol storage full |
| `$09` | `FIXUP` | Unresolved/failed fixup or fixup storage full |
| `$0A` | `LOCAL` | Legacy reserved local-feature status |
| `$0B` | `SERVICE` | Resident lookup/service setup failed |
| other | `FAIL` | Unknown status |

`SEAL` and the `RELOCATE`/`PACKAGE` workers interpret `$01` as `NO END` and
`$02` as `INVALID`. Their operand parsers still use ASM meanings. For example:

```text
ERR OPERAND PC=$2001
ERR FIXUP PC=$2003
SEAL NO END FLAGS=$00
SEAL INVALID FLAGS=$03
REL RANGE
PKG INVALID
LOAD INVALID
INST RANGE
```

AP services use `$06 RANGE`, `$07 INVALID`, `$09 FIXUP`, and `$0B SERVICE`;
unrecognized AP statuses display `FAIL`. The optional `CHECK` worker uses this
same AP mapping. `CHECK` remains disabled in the resident build.
Read-service failures display `READ FAIL`. If service setup fails before
console output is available, ASM returns `$0B` silently as before.
HIMON's generic `EXEC ERR=$hh` and APMAN's own diagnostics are unchanged.

`ERR FIXUP` at `END` usually means one of:

- a label was misspelled or never defined
- a local label was referenced outside its scope
- an import was intended but not declared
- a resident call name was not available in the current HIMON/RJOIN catalog
- 128 live forward-fixup rows were consumed before their targets bound

## Current Gaps

Known limitations:

- No `ASM I` / `ASM B` split yet; typing and pasting use the same line path.
- The physical source-line cap remains 63 visible characters. Compact `DC`
  strings reduce DB-heavy source pressure, but long rows must still be split;
  overlong rows correctly report `ERR LINE`.
- No parentheses or precedence in expressions.
- No forward `EQU` dependency solver.
- Compact raw/CSTR/HBSTR/PSTR `DC` forms and the older comma/double-quote forms
  are current. Embedded apostrophes have no escape spelling yet.
- No default flash-image `CHECK` command.
- No default flash-image `RESOLVE` command; import resolution happens only
  during AP load/run through resident RJOIN.
- `INSTALL pkg flash_addr` writes only erased currently visible low flash.
- `INSTALL pkg Bn` invokes APMAN for a single named AP carrier in the first
  safe erased sector of Bank 0, 1, or 2.
- `LOAD` validates the AP v2 envelope and BODY FNV and performs resident RJOIN
  linking, but there is no general dependency manager yet.
- Local labels are not exported, imported, or reported as public symbols.

For design detail, see [HASHED_ASM.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/HASHED_ASM.md). For board evidence, see
[TEST_PLAN.md](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/ASM/TEST_PLAN.md).
