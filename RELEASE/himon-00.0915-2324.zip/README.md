# HIMON 00.0915(2324)

Built 2026-09-15T23:44:41.933217-05:00. This package is a local release from the
recorded source revision; `MANIFEST.json` records its working-tree status and
file hashes. Source snapshots are reference material; the repository contains
the complete build system. No proprietary tools, WDC firmware, owner bank
dumps, BASIC or Forth products are included.

Start with [the included manuals](MANUALS.md) for operator, technical,
installation, memory-map, assembler, and application instructions.

## Install

Requires STR8-N 1.34. From HIMON enter `STR8`, confirm, then select `S`.
At `STR8-N>` enter `I`, bank `3`, range `C-E`, and confirm `Y`.
Only after `S19` appears send `FIRMWARE/ryors-v1.2-himon-bank3-c-e.s19`. Wait for
`COMMIT? Y:`, confirm `Y`, and require `OK`. Enter `C` to start HIMON;
`ASM NEW` enters ASM-F2. Send text with CR line endings at 115200 baud.

For a new combined installation, or recovery of an interrupted transaction,
use `I / 3 / 8-E` with `FIRMWARE/ryors-v1.2-himon-asm-bank3-8-e.s19` instead. Its S9 is `$C000`.
The ASM-only stream's S9 `$FFFF` retains an existing HIMON directory entry;
it cannot enroll an empty bank. An incomplete Bank-3 transaction requires
the complete writable range 8-E. Bank-3 sector F is owned by STR8 and is not
included in these streams. The BIN is only the address-labelled component
range, not a complete bootable ROM or a whole-bank replacement.

## Qualification

The complete host regression and image checks passed. The combined 28 KiB
payload is byte-identical to the physical-reset-qualified COM4 firmware
except for its three timestamp strings, now `0915(2324)`. The new stamped
stream was not reflashed. Read `QUALIFICATION.json` for exact comparison,
hashes, prior board identities, and limits. Current hardware is unchanged.
Application proof varies; consult `APPLICATIONS/README.md` before use.

## Verify

Extract the ZIP and run `python -B VERIFY.py` (Python 3.9 or newer).
The verifier checks the exact inventory, hashes, notices, record checksums,
S9 entries, component BIN/S19 agreement, and combined image identity.
`SHA256SUMS.txt` covers every other package file. Preserve LICENSE and all
application-specific attribution and redistribution notices.
