# R-YORS Operator's Guide

This guide covers the current R-YORS/STR8-N split. R-YORS owns ASM-F2 and
HIMON at `$8000-$EFFF`. The adjacent standalone STR8-N repository owns the
reset supervisor, protected sector `$F000-$FFFF`, flash-install streams, Bank
Maintenance, top updater, and directory refresh tool.

Historical combined-image procedures and their hardware transcripts remain
under `DOC/GUIDES/STR8/` and `DOC/GUIDES/LOGS/`; do not use their old R-YORS
build target names for a current installation.

## Safety

Keep a verified external-programmer STR8-N BIN before changing flash. Do not
press RESET or NMI, remove power, or interrupt a transfer while a STR8-N erase,
program, restore, or protected-top operation is active.

Banks 0-2 are opaque guest systems after `J0`-`J2`. Physical RESET is the
universal return to Bank 3.

## Build And Image Ownership

With sibling checkouts named `R-YORS` and `STR8-N`:

```text
make all
```

R-YORS verifies the locked STR8-N manifest and public ABI, then builds:

```text
SRC/BUILD/s19/ryors-v1.2-asm-bank3-8-b.s19
SRC/BUILD/s19/ryors-v1.2-himon-bank3-c-e.s19
SRC/BUILD/s19/ryors-v1.2-himon-asm-bank3-8-e.s19
```

The last file is the dense 28K `$8000-$EFFF` payload. Published copies are in
the [current release packages](https://github.com/95westus/R-YORS/blob/himon-v00.0915-2324/RELEASE/README.md): STR8-N v1.34,
HIMON `00.0915(2324)`, and ASM-F2 `00.0915(2324)`. HIMON and ASM-F2 ZIPs
put firmware under `FIRMWARE/` and include the combined `8-E` stream. The
loose `RELEASE/ryors-v1.2-himon-asm-bank3-8-e.s19` matches those copies.
Each package includes relevant manuals, applications, notices, and its own
verifier; run that verifier before installation. Older `RELEASE/ARTIFACTS/`
files are historical snapshots.

The restamped release has full host regression and exact timestamp-only
equivalence to the reset-tested board, with nine differing bytes. It has not
been reflashed. Actual board banners remain HIMON `00.0915(2233)` and
ASM-F2 `00.0915(2243)` until a release install is performed.

To compose a complete 32K Bank-0/1/2 payload, use the product that owns sector F:

```text
make -C ../STR8-N ryors-full-bank
```

This writes:

```text
../STR8-N/BUILD/v1.34/s19/ryors-v1.2-str8n-himon-asm-bank0-2-8-f.s19
```

STR8-N validates the 28K S19, appends its current checked 4K top image, and
verifies the final RESET vector. For Bank 3, install `$8000-$EFFF` through the
guarded `I` path and update sector F only with the standalone programmer BIN
or guarded top updater.

The packaged HIMON BIN covers only `$C000-$EFFF` (12 KiB); the ASM-F2 BIN
covers only `$8000-$BFFF` (16 KiB). Neither is a whole-bank bootable image.
Install HIMON first when applying separate components. Its S9 `$C000`
establishes the Bank-3 entry; the current ASM-only S9 `$FFFF` retains it.
After COMMIT and `OK`, enter `C` for HIMON, then `ASM NEW` for ASM-F2.

For a HIMON-only APv2 update, build `make -C SRC himon-apv2-install-s19`.
At the STR8-N prompt choose `I`, Bank 3, range `C-E`, confirm the displayed
range, and send `SRC/BUILD/s19/himon-apv2-bank3-c-e.s19` only after STR8-N
prints `S19`. The file is a dense payload-only `$C000-$EFFF` stream with S9
`$C000`; it contains no `$0200` worker records and never writes sector F.

Use `STR8N_HOME=<path>` when the repositories are not siblings. `make release`
also requires the locked standalone STR8-N checkout to be clean.

## Current Integrated Layout

```text
$8000-$BB82   ASM-F2, entry $800C
$BB83-$BFFF   low-flash growth margin, 1,149 bytes
$C000-$EDE9   HIMON
$EDEA-$EFFF   HIMON growth margin, 534 bytes
$F000-$FCF1   standalone STR8-N v1.34 resident
$FCF2-$FD77   available 134-byte growth margin
$FD78-$FFAF   stored unified STR8-N worker, runs at $0200-$0437
$FFB0-$FFEF   bank directory
$FFF0-$FFF9   configuration pocket
$FFFA-$FFFF   STR8-N-owned hardware vectors
```

The Bank Jump Record is RAM `$7DFD-$7DFF = 42 4A nn`, with `$FF` meaning no
validated target is known.

## Reset And STR8-N

At physical RESET, STR8-N offers its attach/selection interval and then starts
compatible Bank-3 HIMON unless the operator selects STR8-N or another guest.
It emits a leading CR/LF followed by `RST H` for hardware or unmarked reset
entry. A cooperating software path emits `RST S` by committing the one-shot
`RS` record at `$7DE7-$7DE8`; STR8-N consumes that record on entry.
The current resident commands are:

```text
I        install a dense payload S19 in a selected legal flash-sector range
L        load a recovery S19 into RAM and execute its S9 entry
C        cold-enter compatible Bank-3 HIMON at $C000
W        warm-enter compatible Bank-3 HIMON at $C000
J0-J2    enter an enrolled Bank 0, 1, or 2 guest
J3       hand off through the Bank-3 RESET vector
```

STR8-N `L` accepts RAM `$2000-$7AFF` and always executes a valid in-range S9.
Ctrl-C aborts without executing. Use it for the standalone Bank Maintenance,
console ABI probe, protected-top updater, and directory refresh artifacts.

The exact prompts, confirmations, recovery states, and artifact names are in
the standalone [STR8-N Operator's Guide](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/OPERATORS_GUIDE.md)
when the repositories are sibling folders.

## HIMON Commands

```text
?              help
# [token]      list records, or resolve a token without executing it
D start [end]  dump one byte or an inclusive address range
M start [end|+count]  modify RAM below $7A00
G addr         execute an address
STR8           enter resident STR8-N at $F000 after confirmation
L              load S0/S1/S9 into RAM and report the S9 address
ASM            enter flash-resident ASM-F2 when present
AP ...         load/link/run an AP package
APS ...        map/list/inspect installed AP carriers
R [regs]       display or edit trapped context
B start        set a one-shot breakpoint
B C start      clear a breakpoint
B L            list breakpoints
N              single-step trapped context
X              resume trapped context
```

HIMON `L` is deliberately load-only. It does not execute S9. `L G` and `L F`
are rejected. Each record is parsed by STR8-N's checked `$F009` `SR/02`
service; HIMON has no private S19 parser and fails closed if that owner is
absent or incompatible. To run a loaded program, inspect the reported S9 and
issue an explicit `G address`. HIMON rejects S1 spans at `$7A00` or above and
rejects flash destinations.

If a record is malformed or targets protected/flash space, HIMON prints the
loader error, poisons that load, and silently consumes the remaining S-records
through S9 before returning to its prompt. Later S1 records are not written.
Press Ctrl-C if a failed or truncated sender will not provide S9. Earlier valid
RAM records are retained; cancellation and failure are not rollback.

Example:

```text
>L
...send a RAM S19...
L OK ... GO=2000
>G 2000
```

This differs intentionally from STR8-N `L`, whose recovery workflow loads and
runs in one operation.

## A Complete Named-Carrier Session

ASM-F2 is already resident in the normal R-YORS 28K payload. This is the
short path from source to a named carrier that remains usable after reset:

```text
>ASM NEW
ASM>$2000: ORG $2000
ASM>$2000: MAIN LDA #$5A
ASM>$2002: RTS
ASM>$2003: ENTRY MAIN
ASM>$2003: END
SEAL> PACKAGE MAIN $3000
SEAL> INSTALL 3000 B2
SEAL> .
[press physical RESET and select C]
>APS B2 MAIN
>AP B2 MAIN
```

After `END`, `PACKAGE name address` emits the AP-v2 envelope. `INSTALL address
Bn` asks the installed APMAN carrier to choose the first completely erased 4K
sector in Bank 0, 1, or 2, program the envelope, and restore Bank 3. `APS`
checks discovery after reset; `AP` loads, links, and runs it. `AP L` performs
the same named load/link without transferring control.

The earlier carrier qualification installed APMAN at B2:8; it runs transiently
at `$7000`. You do not preload APMAN; HIMON loads the installed APMAN carrier
automatically when an APMAN-backed command is entered. BANKDUMP at B2:9 supplied
read-only header/page/all-sector inspection and the full `E/U/A/W/B/P` map
in that historical configuration. The 2026-09-15 firmware tests did not
requalify these persistent carriers; inspect the current media before using
this workflow.
See the [APMAN card](../../APPLICATIONS/APMAN/HISTORICAL-BOARD-TEST.md) and
[BANKDUMP card](ASM/BANK_DUMP_AP_CARD.md).

An optional checked ASM build includes full AP checking and consumes extra
flash space. The released compact build leaves `$047D` (1,149 bytes) of
headroom. The checked variant is a separate diagnostic build; its size and
identity are not the released image's values.

## RAM Debug Loop

```text
make -C SRC life
>L
...send SRC/BUILD/s19/life-2000.s19...
>B 2000
>G 2000
```

Set breakpoints after loading. HIMON `L` clears active debug patches. Debug
patch targets are limited to user RAM; monitor RAM, I/O, and flash are
protected.

## Import/Export Boundary

R-YORS has complete host-side build/export products for ASM/HIMON S19, AP
package construction, and the verified 28K integration payload. STR8-N owns
guest BIN normalization, dense install payload preparation, the full 32K
composer, protected-top artifacts, and the release manifest. There is no
resident general flash-to-S19 export command; preserve programmer readbacks
and host artifacts for full-image export and recovery.

## Further Reference

- [Complete WDCMONv2-to-R-YORS installation flow](INSTALLATION_FLOW.md)
- [Memory Map](MEMORY/MEMORY_MAP.md)
- [HIMON Map](HIMON/HIMON_MAP.md)
- [ASM User Guide](ASM/ASM_USER_GUIDE.md)
- [AP And OIL Guide](AP/AP_OIL_GUIDE.md)
- [STR8-N integration boundary](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/STR8/PRODUCT_BOUNDARIES.md)
- [Hardware test log](https://github.com/95westus/R-YORS/blob/bbb55a80fd3a976f2e846a3dac7adbf4a75bdf60/DOC/GUIDES/LOGS/HARDWARE_TEST_LOG.md)
