# Manuals included in this package

- [GUIDE](APPLICATIONS/MICROCHESS/GUIDE.md)
- [README](APPLICATIONS/README.md)
- [AP_OIL_GUIDE](DOC/GUIDES/AP/AP_OIL_GUIDE.md)
- [ADDRESS_PRACTICES](DOC/GUIDES/ASM/ADDRESS_PRACTICES.md)
- [ASM_ABI_V1](DOC/GUIDES/ASM/ASM_ABI_V1.md)
- [ASM_USER_GUIDE](DOC/GUIDES/ASM/ASM_USER_GUIDE.md)
- [BANK_AUDIT_AP_CARD](DOC/GUIDES/ASM/BANK_AUDIT_AP_CARD.md)
- [BANK_DUMP_AP_CARD](DOC/GUIDES/ASM/BANK_DUMP_AP_CARD.md)
- [PIA_LED_BANKED_AP_CARD](DOC/GUIDES/ASM/PIA_LED_BANKED_AP_CARD.md)
- [CAPABILITIES](DOC/GUIDES/CAPABILITIES.md)
- [GLOSSARY](DOC/GUIDES/GLOSSARY.md)
- [HIMON_DEBUG_TESTING](DOC/GUIDES/HIMON/HIMON_DEBUG_TESTING.md)
- [HIMON_MAP](DOC/GUIDES/HIMON/HIMON_MAP.md)
- [INSTALLATION_FLOW](DOC/GUIDES/INSTALLATION_FLOW.md)
- [MEMORY_MAP](DOC/GUIDES/MEMORY/MEMORY_MAP.md)
- [OPERATORS_GUIDE](DOC/GUIDES/OPERATORS_GUIDE.md)
- [REF](DOC/GUIDES/REF.md)
- [RELEASES](DOC/GUIDES/RELEASES.md)
- [RELEASE_APPLICATIONS](DOC/GUIDES/RELEASE_APPLICATIONS.md)
- [TECHNICAL_GUIDE](DOC/GUIDES/TECHNICAL_GUIDE.md)

Included manuals work offline. References to source files or historical material
outside this package are explicit GitHub links pinned to the source commit
or release tag; they require those references to be published. Dated qualification records and
historical board cards are preserved unchanged; raw-log references require
the original repository. Start with README.md for this release identity.
