# APMAN optional carrier manager

The AP v2 envelope is `apman-v1.ap`. The matching dense BIN/S19 occupies one
4 KiB sector at Bank 2:$8000-$8FFF; it is an initial bootstrap carrier, not
a whole-bank image. It replaces that sector when installed. It does not
contain any WDC firmware or a snapshot of an owner's bank.

For an already provisioned APMAN carrier, ASM's `INSTALL package Bn` and
HIMON's AP/APS commands use the current resident protocol. A suitable free
destination sector is required. Inspect the directory and bank contents
before choosing any installation destination.

New carrier provisioning also requires a consistent STR8 directory entry.
It depends on the current bank's state and is not automatic on running a
game or assembler example. The STR8 package includes Bank Maintenance and
its operator guide for directory/flash work. `HISTORICAL-BOARD-TEST.md`
records an earlier destructive bench setup; it is evidence, not a script to
paste into a current board. The 2026-09-15 firmware qualification did not
requalify an APMAN carrier installation. Run the other packaged AP examples
from RAM when persistent installation is not needed.
