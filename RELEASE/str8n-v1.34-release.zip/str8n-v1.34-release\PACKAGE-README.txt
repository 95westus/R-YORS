STR8-N v1.34 standalone release

Start with README.md for the manual index, then DOC/OPERATORS_GUIDE.md.

Installation:
  ARTIFACTS/str8n-v1.34-bank3-f000-ffff.bin is the exact 4096-byte
  programmer image for Bank 3 CPU F000-FFFF (device offset 1F000).
  ARTIFACTS/str8n-v1.34-f000.s19 is the resident image for build/integration;
  the resident I command cannot overwrite its own protected top sector.
  Existing STR8-N installations use the guarded RAM top-update image and
  its documented backup/confirmation procedure.

Factory WDC-to-STR8 migration:
  Extract PACKAGES/str8n-v1.34-wdcmonv2-str8n-migration-kit.zip separately.
  Read QUICKSTART.txt and follow the screen. The accepted v1.34 Windows
  procedure used -PhysicalResetArmSeconds 60 and RESET during its arm window.
  CTRL+U and CTRL+D send different files; press each once and only when requested.
  After J0, physical RESET is the designed return from the factory system.
  This kit supplies project-written migration tools, not WDC firmware.
  Keep any bank archives created during migration owner-local.

Maintenance:
  ARTIFACTS contains RAM Bank Maintenance, its expanded menu, guarded top
  update, and directory refresh. STR8 L loads and starts their S9 entry.
  Directory refresh replaces directory records; follow its operator guide.
  APPLICATIONS/str8n-v1.34-bank-maint-menu-2000.a is the corresponding
  ASM-F2 DB image carrier: ASM NEW, send the complete file, SEAL> ., G 2000.
  It emits 12288 bytes at 2000-4FFF and embeds the canonical top at 4000.
  ASM-F2 and HIMON are separate prerequisites for this .a workflow.
  Stop on any ERR= response. Its maintenance menu includes flash writes.
  TOOLS supplies guest BIN conversion and dense installer-S19 preparation.
  TESTS contains optional console/interrupt/worker qualification programs;
  the worker test writes/erases a selected sector. Follow its test report.

Qualification:
  The exact canonical v1.34 firmware passed guarded update/readback,
  power/physical/software reset, NMI/VIA1 IRQ/BRK, console, HIMON/ASM,
  J3, worker program/erase, and the complete Windows factory migration.
  See the three 2026-09-15 board reports. Bank 1/2 guest boots, transient
  LED timing, injected failure/recovery, and Linux migration remain
  unqualified by those reports. No new hardware run is claimed here.

Verification and redistribution:
  Run powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\VERIFY-PACKAGE.ps1
  The verifier checks the exact inventory, hashes, S-records, canonical
  firmware, maintenance .a/S19 equality, and the nested migration inventory.
  CHECK-LINKS.ps1 checks local manual destinations and headings. Historical
  evidence not bundled here links to the source repository at the recorded commit.
  PACKAGE-MANIFEST.json records packaging time and unchanged firmware identity.
  SHA256SUMS.txt covers every other packaged file, including the manifest.
  LICENSE is the project MIT license. No WDC tools, WDCMON firmware, stock
  bank images, owner captures, HIMON/ASM payloads, or games are included.
  HIMON and ASM-F2 applications are distributed in their own release packages.