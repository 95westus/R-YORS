# STR8-N v1.34 Operator's Guide

## EDU LED patterns (v1.34)

These are the implemented patterns while STR8-N owns the optional EDU LEDs.
The four red LEDs use bits 7-4; the four green LEDs use bits 3-0. In the
table, bits run from 7 down to 0, and `1` means illuminated.

| Value | Red bits / green bits | Meaning |
| --- | --- | --- |
| `$00` | `0000 / 0000` | Display released; the next application owns it |
| `$01` | `0000 / 0001` | Running; also restored when the resident flash worker returns |
| `$21` | `0010 / 0001` | Waiting for input; FTDI unconfigured or suspended |
| `$43` | `0100 / 0011` | Waiting for input; FTDI configured |
| `$07` | `0000 / 0111` | Receive activity |
| `$0B` | `0000 / 1011` | Transmit activity |
| `$F0` | `1111 / 0000` | Flash mutation or its required verification is active |

**All four red LEDs on, all green off (`$F0`): leave RESET, NMI, USB, and
power untouched during the active flash operation.** Follow the terminal's
prompts and verification result; LEDs alone do not establish success or
permission to interrupt an operation.

Activity patterns latch until another state replaces them. A steady `$07`
or `$0B` is not a transfer-rate indicator. There is **no periodic heartbeat**
in v1.34. Host presence is sampled when entering the main command wait;
`$43` does not prove a terminal application is open, and a host change need
not appear until the next command wait.

The resident flash worker restores `$01` on both successful and failed
returns. The factory migration/restore RAM tool instead clears its `$F0`
display to `$00` after successful verification before waiting or handing
off. Neither `$01` nor all LEDs off is a standalone success indication.

After handoff to HIMON, ASM-F2, a WDC guest, or another application, that
program may display its own patterns. This legend no longer defines their
meaning. Public STR8-N console calls leave the application's LEDs alone.

The old `$41` unsampled input-wait pattern is historical; the current main
command wait uses `$21` or `$43`. Detailed red error codes and heartbeat
patterns in the [design record](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/LED_STATUS_PROPOSAL.md) are proposals, not
implemented v1.34 diagnostics.

## Validation status

The v1.22 `C`/`W` selector and warm timeout were board-accepted by the operator
on 2026-08-19. The exact test card, retained transcript, and acceptance are in
[STR8N_V1_22_WARM_DEFAULT_BOARD_TEST.md](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/STR8N_V1_22_WARM_DEFAULT_BOARD_TEST.md).
Version 1.34 is the current size-optimized release. Its
[COM4 board test](STR8N_V1_34_BOARD_TEST_2026-09-15.md) passed guarded update,
exact readback, physical/software reset, console/BRK, HIMON/ASM, and J3;
the [follow-up tests](STR8N_V1_34_FOLLOWUP_BOARD_TEST_2026-09-15.md) also passed
power-cycle startup, NMI/IRQ, and optimized-worker program/erase on erased
B2:9. Broader qualification remains incomplete. It retains the reset-source and immediate-banner
behavior. The accepted v1.33 binary passed guarded top update, exact readback,
software-reset entry, and HIMON warm recovery on COM4 on 2026-09-10. The
private `$07` receive and `$0B` transmit LED behavior remains from v1.31. The
complete v1.32 factory migration and its RAM-worker `$F0` mutation indication
passed on COM4 on 2026-09-08. The
[complete v1.34 migration](STR8N_V1_34_FACTORY_MIGRATION_BOARD_TEST_2026-09-15.md)
also passed on 2026-09-15, without adding visual LED observations. See the
[I/O activity proof](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/LED_IO_ACTIVITY_BOARD_TEST_2026-09-06.md), the
[v1.33 top-update board report](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/STR8N_V1_33_TOP_UPDATE_BOARD_TEST_2026-09-10.md), the
[v1.32 reset-source board report](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/STR8N_V1_32_RESET_SOURCE_BOARD_TEST_2026-09-07.md), the
[factory-migration board report](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/WDCMONV2_MIGRATION_BOARD_TEST.md), the
[host-presence proof](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/LED_HOST_PRESENCE_BOARD_TEST_2026-09-06.md), and the
[original v1.30 board evidence](https://github.com/95westus/STR8-N/blob/846032d48e4345e389dfd6b0b5d40c1e70e10129/docs/STR8N_V1_30_RECLAIM.md).

The [v1.34 size-change report](STR8N_V1_34_SIZE_OPTIMIZATION.md) separates the
current host checks from the remaining hardware work.

This is the board-facing guide. You do not need to know assembly language to
use it.

For complete sample terminal sessions, see [Worked Examples](EXAMPLES.md).

## Which loader should I use?

No: STR8-N `I` cannot load programs into RAM. It installs a dense S19 image
into flash. STR8-N now has a separate recovery command, `L`, for RAM.

```text
Need                         Use             Destination
install a lasting image      STR8-N I        selected flash bank
recovery load and execute    STR8-N L        RAM $2000-$7AFF, then S9
load without starting        HIMON L         RAM under HIMON policy
start after a HIMON load     HIMON G address explicit address from L report
start a flash-bank guest     STR8-N J0-J3    selected bank's RESET vector
```

STR8-N `L` is deliberately smaller than HIMON's loader. It always starts the
program, has one fixed safe range, and provides no load-only or fallback-entry
mode. That makes it useful when the normal Bank-3 payload needs repair.

For normal R-YORS programs loaded by HIMON, `$2000-$4FFF` is the simplest
general-purpose area. More RAM may be available, but check the R-YORS memory
map before using ASM work areas or monitor workspace. HIMON `L` can write
lower RAM too, but loading over active workspace can damage the current
monitor session.

### Factory WDCMONv2 board

Do not paste an S19 into stock WDCMONv2. Use the allowlisted migration kit's
binary-protocol wrapper:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass `
  -File .\STR8-iN65-LOADER.ps1 -Port COM4 -PhysicalResetArmSeconds 60
```

Press physical RESET while the launcher reports that its reset-arm window
is active. This is the accepted v1.34 Windows procedure.

The accepted path requires a factory board with B0 erased or already
byte-identical to B3. It copies and exactly verifies all of B3 in B0, installs
STR8-N 1.34 only in B3:F, and then guides the operator through publishing the
retained WDCMONv2 system as COMPLETE D0 `WDCV2`. B1/B2 are untouched.
Migration stops at STR8-N; HIMON and ASM-F2 are optional later component
loads, not migration payloads.

Read the utility's screen before entering a command or pressing a control key.
`Ctrl+U` and `Ctrl+D` send different packaged files and must be used only when
the screen explicitly requests them, once each. After `J0`, the preserved
factory system owns the computer. Physical RESET is the designed way to return
to STR8-N; this is intentional, not a flaw. Follow
[WDCMONV2_MIGRATION.md](WDCMONV2_MIGRATION.md) for the complete procedure.

## Before writing flash

1. Keep the 4096-byte STR8-N top-sector BIN and an external programmer or
   another proven recovery method.
2. Know which bank and which 4K sectors the S19 file was made for.
3. Keep power and the FTDI serial connection steady.
4. Do not press NMI or RESET during an erase or write.
5. Remember that `WRITE? Y` allows the transaction to begin. It is not a dry
   S19 validation pass.

> [!WARNING]
> After `WRITE? Y`, STR8-N journals START before printing `S19`. As each
> complete 4K sector arrives, it may be erased, programmed, and verified.
> Only the final selected sector waits for `COMMIT? Y`. A later bad record,
> disconnect, RESET, NMI, power loss, or declined commit leaves the bank
> incomplete and requires the full recovery range.

## What happens at RESET

Physical RESET always returns the hardware to Bank 3 and starts STR8-N. The
reset-source line has a leading blank line. `RST H` means physical reset or an
unmarked legacy entry; `RST S` means a cooperating software path committed the
one-shot reset record immediately before entering STR8-N. Two linefeeds follow
the marker:

```text
RST H

STR8-N 1.34
0-2 C W S:
```

STR8-N discards stale queued input before printing the identity and immediately
opens the silent six-second live selector interval.

- `0`, `1`, or `2` starts a completed guest in that bank.
- `C` cold-starts compatible HIMON at `$C000` in Bank 3.
- `W` warm-starts compatible HIMON at `$C000` in Bank 3 and preserves RAM.
- `S` stays in STR8-N and displays `STR8-N>`.
- If no key is pressed, STR8-N warm-starts compatible HIMON and preserves RAM.

Starting a guest is a full handoff, not a temporary call into that system.
In particular, after selector `0` or command `J0` starts the preserved factory
system, press physical RESET to return to STR8-N. That reset-only return is by
design.

A key may take up to one second to be noticed. Unmarked legacy `J3` and
physical RESET use the same sequence; only paths that implement the published
`RS` record can report `RST S`.

At `STR8-N>`, the visible commands are:

```text
I       install an S19 into flash
L       load an S19 into $2000-$7AFF and execute its S9 address
C       cold-enter compatible HIMON in Bank 3
W       warm-enter compatible HIMON in Bank 3
J0-J3   select a bank and jump through its RESET vector
```

An improper command is discarded. Enter a valid command; the command text is
not printed again merely because a bad key was pressed.

## Install an image with I

The same procedure applies to every bank.

1. At `STR8-N>`, type `I`.
2. At `B0-3:`, enter the bank number.
3. At `RANGE:`, enter one sector digit or the first and last 4K sector digits.
   Examples: `8-F` means `$8000-$FFFF`; `C-E` means `$C000-$EFFF`; `A` means
   `$A000-$AFFF`.
4. For a new bank-directory row, enter the requested two-digit hexadecimal
   `TYPE:` and exactly five characters at `DESC:`. A description may use
   `A-Z`, `0-9`, hyphen, underscore, or period. These identity fields cannot
   be changed without refreshing the protected sector.
5. Read the `I Bn x-y` summary. At `WRITE? Y:`, type `Y` only if the bank and
   range are correct.
6. When `S19` appears, send the payload-only S19 through the FTDI console.
   There is no separate worker file to send.
7. A dot means one 4K sector has already been programmed and read back. For a
   multi-sector file, dots can appear while the S19 is still being received.
8. After STR8-N accepts S9, it prints `COMMIT? Y:`. Type `Y` to program the
   held final sector and finish the directory transaction.
9. `OK` means COMPLETE was journaled and the transaction is usable. `FAIL`
   means do not try to boot that bank; use the recovery procedure below.

### Full-speed terminal transfer

Use ordinary text-file sending with zero character delay and zero line delay.
No STR8-N-specific macro, terminal brand, or software flow-control setting is
required.

After `WRITE? Y`, STR8-N copies its RAM worker and opens the persistent
transaction before it prints `S19`. On a new bank row, START, metadata, and the
identity seal are therefore complete before the terminal is invited to send.
Once `S19` appears, send the complete file continuously at full speed.

Because `Y` now opens the transaction before S19 validation, cancelling or
losing power after `Y` leaves an incomplete directory row. Use the documented
full-range recovery procedure on the next boot.

The S19 must contain the exact range selected at the prompts, including every
`$FF` padding byte. Do not send an old stream with `$0200` worker records.

If STR8-N detects a fatal record, density, range, entry, or worker error before
S9, it latches the failure and silently consumes the rest of the transfer
through a syntactically valid S9. Ctrl-C is the escape for a truncated or
stopped transfer. Only then does STR8-N print `FAIL` and reopen its prompt, so
USB packet gaps cannot expose the remaining S-record lines as commands. This
input quench does not roll back START, an INCOMPLETE directory row, or any
non-final sectors already programmed.

## Load and execute a RAM recovery program with L

STR8-N `L` changes RAM only. It does not erase or program flash and does not
ask for confirmation.

1. At `STR8-N>`, type `L`.
2. When `S19` appears, send an S19 containing S0/S1/S9 records.
3. Every nonempty S1 record must fit completely within `$2000-$7AFF`.
4. At least one S1 record is required.
5. S9 must name an execution address within `$2000-$7AFF`.
6. As soon as the valid S9 is received, STR8-N disables IRQ, clears decimal
   mode, sets X and the stack pointer to `$FF`, and jumps to S9. A/Y and other
   RAM or peripheral state are not initialized for the program.

There is no `L G`, separate `G`, confirmation, or load-only form in STR8-N.
The recovery program must initialize the hardware and RAM state it needs.
It should not execute `RTS` to return because STR8-N deliberately replaces the
stack pointer before entry. Physical RESET returns to Bank 3 and STR8-N.

The RAM stream does not need to be dense, ascending, or 4K-aligned. Each S1
record is checked independently; overlapping records are applied in received
order. S2-S8, bad checksums, empty S1 records, an out-of-range record span, an
out-of-range S9, or a stream with no S1 fail. On failure STR8-N does not
execute, but bytes copied by earlier valid records remain in RAM. A failure
before S9 poisons the session: later S1 records are parsed and discarded until
a syntactically valid S9 ends the transfer. If the sender stops without S9,
press Ctrl-C to return to the prompt.

Ctrl-C (`$03`) while `L` is receiving S19 cancels the load. The on-board
STR8-N 1.34 image reports `BAD`, returns to `STR8-N>`, and does not execute the
S9 entry. Complete S1 records accepted before Ctrl-C remain in RAM; cancellation
is not rollback. Ctrl-C is also the explicit terminator while STR8-N is
quenching a failed transfer.

`$7B00` is the first protected parser buffer byte. The highest accepted byte
is therefore `$7AFF`, even when one S1 record crosses a page boundary. Stop
sending after S9; queued serial bytes are inherited by the recovery program.

### Load the STR8-N 1.34 bank-maintenance program

Use `BUILD/v1.34/s19/str8n-v1.34-bank-maint-2000.s19`. It is a temporary RAM tool;
loading it does not change flash. It does not require HIMON and uses the
board's FT245R console directly.

1. At `STR8-N>`, type `L`.
2. When `S19` appears, send
   `BUILD/v1.34/s19/str8n-v1.34-bank-maint-2000.s19` at normal full speed.
3. STR8-N validates the file and starts it automatically at `$2000`.

The menu commands are:

```text
M  map every bank and show the Bank-3 directory; does not write flash
C  copy a complete 32K bank and enroll its empty destination directory row
D  adopt an existing payload into an empty directory row; payload is read-only
N  rename one COMPLETE D0-D3 five-character description through guarded B3:F rewrite
E  erase selected 4K sectors; Bank 3 sector F is always protected
P  install the narrow, validated AP carrier at Bank 0 $BF00
R  clear an erased D0-D2 row, or compact an exhausted D3 install journal
Q  return to STR8-N through $F000
```

At the Bank Maintenance main menu, an empty line (Enter by itself) is the same
as `Q`: it leaves Bank Maintenance and returns to STR8-N. Ctrl-C and empty
lines at operation subprompts cancel that operation and return to the Bank
Maintenance menu.

The shortest safe rule is: use `M` freely; treat `C`, `D`, `E`, `N`, `P`, and
`R` as flash operations. `N` requires exact `RENAME Dn XXXXX` and preserves
the selected row's type, seal, entry, and journal.

### Upgrade Bank 3 sector F to STR8-N v1.34

The v1.34 release includes the RAM-resident updater
`BUILD/v1.34/s19/str8n-v1.34-top-update-2000.s19`. It is loaded by the existing
STR8-N `L` command and runs entirely from RAM while Bank-3 sector F is erased.
An external programmer remains the preferred first-board and recovery method.
This maintained Top Update artifact replaces the older ASM-generated
TopWriter workflow; those TopWriters are historical, not the current update
path.

The complete onboard sequence through backup verification, Bank-3 sector-F
program/verify, RESET, and live `S` selection was accepted on hardware on
2026-08-11. The recovery commands remain mandatory safeguards; external
restore is still a separate acceptance gate.

Before starting:

1. Keep both the v1.1 rollback BIN and
   `BUILD/v1.34/bin/str8n-v1.34-bank3-f000-ffff.bin` off-board.
2. Confirm Bank 1 CPU `$F000-$FFFF` may be replaced by the fresh protected
   raw backup (`STR8_TOP_SAFE`, physical `$0F000-$0FFFF`). The successful
   updater leaves that backup in place; it is not scratch space afterward.
3. Install `ryors-v1.2-himon-asm-bank3-8-e.s19` into Bank 3 sectors `8-E`
   using the existing STR8-N `I` command.
4. Return to STR8-N; do not use old ASM to write `$7Dxx` during the migration
   window.

Then update the protected top sector:

1. Type `L` and send `str8n-v1.34-top-update-2000.s19` at normal full speed.
2. Check that the tool prints `BACKUP B1:F; TARGET B3:F`.
3. Type the exact first confirmation `BACKUP B1F` only if Bank 1 sector F may
   be replaced by the fresh protected backup.
4. Require `BACKUP VERIFIED` before continuing.
5. Type the exact final confirmation `STR8-N 1.34`.
6. Do not press NMI or RESET, remove power, or disturb the flash/FTDI hardware
   until the tool reports verification and enters the new RESET vector.

At either typed confirmation, Enter by itself cancels before active erase,
prints `ABORT - NO ACTIVE TOP UPDATE`, and returns to STR8-N. Any other
nonmatching confirmation has the same safe result.

If active programming fails, do not reset. At the RAM recovery prompt use `R`
to retry the embedded v1.34 image or `O` to restore the verified Bank-1 backup.
If the RAM tool cannot recover, externally copy physical `$0F000-$0FFFF` back
to `$1F000-$1FFFF`, or program one of the retained 4096-byte BINs at physical
`$1F000`.

After v1.34 starts, verify `S`, `C`, `W`, selector timeout, the
`$7DFD-$7DFF` Bank Jump Record, and the ASM `$7CFF/$7D00` boundary before
updating Banks 0-2.

`C`, `D`, `N`, `E`, `P`, and `R` write flash and require an exact typed
confirmation. The combined menu's `U` top update and the isolated STR8-iN/65
tool's `F` search-flag update also write flash under their own exact gates.
Do not press NMI, reset, remove power, or remove the flash during a write or
erase. `C` prints `!STR8` before confirmation when the source contains the
STR8-N 1.34 `SR 02 03` service signature. `Q` starts the normal STR8-N startup
display again; the timing interval is deliberately silent in v1.34.

`C` accepts source Bank 0-3 and destination Bank 0-2. The destination's
Bank-3 directory row must be completely erased; otherwise it prints
`DIR NOT EMPTY` and does not copy. After all eight sectors are copied and
verified, enter a two-digit hexadecimal TYPE and exactly five DESCRIPTION
characters, then answer `ENROLL? Y`. Allowed description characters are
`A-Z`, `0-9`, hyphen, underscore, and period.

Enrollment writes the journal START marker first, the immutable identity
second, and COMPLETE last. `OK` therefore means both the 32K copy and its
directory enrollment were verified, and `J0`-`J2` may use the destination.
If enrollment is cancelled, interrupted, or fails, the copied bytes can
remain in the destination but STR8-N keeps that bank non-bootable. If the row
is still completely erased and the copied payload has a valid RESET vector,
`D` can enroll it later without copying the payload again. A nonempty or
incomplete directory row must not be overwritten by `C` or `D`.

`E` erases payload sectors but cannot restore the corresponding Bank-3
directory row: flash programming only clears bits, while D0-D2 require all
`$FF` before reuse. After `E ALL`, use `R`, select the erased Bank 0-2, and
type the exact `CLEAR Dn` confirmation. `R` first verifies all eight payload
sectors are erased. It stages Bank-3 sector F and first writes a verified raw
backup into the selected bank's sector F. It then changes only the directory
row to `$FF`, rewrites and verifies the complete protected sector, and erases
and verifies the temporary backup. Require `BACKUP VERIFIED` before the B3F
rewrite completes. Do not reset, use NMI, remove power, or disconnect the flash
device during `B3F REWRITE`.

`R` also accepts D3 only when its journal is exactly `00000000`. It searches
Banks 0-2, sectors 8-F, for the first completely erased 4K scratch sector and
prints that location before the exact `RESET J3` confirmation. It backs up and
verifies the complete live B3F sector there, changes only D3 journal bytes
`00000000` to `FCFFFFFF`, rewrites and verifies B3F, then erases and verifies
the scratch sector. D3 keeps its TYPE, DESCRIPTION, local entry, and seal; the
single retained COMPLETE pair keeps `J3` launchable and leaves 15 later `I3`
transactions. `J3 NOT FULL` and `NO ERASED SCRATCH` refuse without mutation.
This is an onboard sector rewrite, not a firmware or payload reflash, but it
has the same no-reset/no-NMI/no-power-loss requirement while B3F is active.

`D` adopts an existing payload into a completely erased directory row without
erasing or rewriting any payload sector. It is the metadata-only recovery path
after a directory refresh. Select Bank 0-3, enter TYPE and exactly five DESC
characters, and type the exact confirmation `ADOPT Bn`. The tool rejects a
nonempty row and a missing, low, or erased RESET vector. Banks 0-2 receive the
normal `$FFFF` directory entry because `J0`-`J2` follow their RESET vectors.

Bank 3 additionally requires the current `SR 02 03` STR8-N signature and an
explicit entry from `$8000-$FFFE`; the first two bytes at that entry may not
both be erased. For the current R-YORS Bank-3 payload, use entry `$C000`, TYPE
`FF`, and DESC `RYORS`. Adoption writes journal START first, immutable identity
second, and COMPLETE last. A successful fresh D3 therefore prints as:

```text
D3 FF RYORS C000 FCFFFFFF
```

`D` never edits or replaces an existing identity. Refresh the protected
directory sector again if the desired row is not completely erased.
The erased-row, RESET/ENTRY, DESC-length, cancellation, D1/D3 commit, and
post-adoption `C` regression paths were accepted on hardware on 2026-08-11.
On 2026-08-18 the v1.21 combined menu separately copied a full payload while
leaving D2 erased, adopted it with exact `ADOPT B2`, displayed
`D2 F2 WDCDG FFFF FCFFFFFF`, launched it successfully through `J2`, and
returned to Bank 3 on physical RESET. The payload's observed banner identifies
it only as the factory onboard firmware; the operator-assigned `WDCDG` label
does not establish WDCMONv2 provenance.

The same accepted final state deliberately retains the verified B3:F backup in
B1:F while B1 sectors `8-E` are erased. Current `M` identifies the configured
backup as `B`, so B1 appears `E E E E E E E B`. D1 still contains its former
guest identity, so do not use `J1`. The erase command protects B1:F. `R D1` is safe to try but
cannot reclaim this partial state; it must refuse with `BANK NOT ERASED`.

## Banks 0-2

Banks 0-2 allow any contiguous, 4K-aligned size from 4K through 32K.

Yes, every top-aligned size in this table can be installed:

```text
SIZE   RANGE  ADDRESS RANGE
 4K    F      $F000-$FFFF
 8K    E-F    $E000-$FFFF
12K    D-F    $D000-$FFFF
16K    C-F    $C000-$FFFF
20K    B-F    $B000-$FFFF
24K    A-F    $A000-$FFFF
28K    9-F    $9000-$FFFF
32K    8-F    $8000-$FFFF
```

These are not the only legal ranges. For example, `8-B`, `A-D`, and `C-E`
are also accepted. The rule is simply: one contiguous range, starting and
ending on 4K sector boundaries, wholly inside sectors 8 through F.

```text
RANGE  ADDRESS RANGE   SIZE
8-F    $8000-$FFFF     32K
8-B    $8000-$BFFF     16K
C-E    $C000-$EFFF     12K
E      $E000-$EFFF      4K
```

A normal bootable full-bank image owns:

```text
$8000-$FFF9  guest code, data, and padding
$FFFA-$FFFB  NMI vector, low byte first
$FFFC-$FFFD  RESET vector, low byte first
$FFFE-$FFFF  IRQ/BRK vector, low byte first
```

For a full 32K install, S9 must equal the non-erased RESET vector. `J0`, `J1`,
and `J2` always read the selected bank's RESET vector; they do not jump to S9
or to a directory entry.

A partial image may use S9 `$FFFF` or an address inside its selected range,
but that value is only install metadata. A partial install does not create or
repair the RESET vector unless sector F is included. A first partial install
into an erased bank can complete successfully yet still be unable to boot.

Even when sector F is included, check the RESET vector at `$FFFC-$FFFD`. It
must point to real code in that bank. `J0`-`J2` ignore S9 and follow RESET.

### Full R-YORS 8-F image for Banks 0-2

`make ryors-full-bank` composes the current R-YORS ASM+HIMON 28K payload with
the current STR8-N 1.34 top sector:

```text
C:/SRC/STR8-N/BUILD/v1.34/s19/ryors-v1.2-str8n-himon-asm-bank0-2-8-f.s19
$8000-$BFFF  ASM-F2
$C000-$EFFF  HIMON
$F000-$FFFF  STR8-N 1.34 clone
S9/RESET     $F000
```

Install it with `I`, target Bank 0, 1, or 2, and range `8-F`. It is not a
Bank-3 payload because `I` never writes Bank 3 sector F. `J0`-`J2` enter the
copied STR8-N first; its normal timeout can then enter the same bank's HIMON.
Physical RESET always returns to the real Bank-3 STR8-N.

## Bank 3 and the R-YORS v1.2 files

Bank 3 permits 4K through 28K in sectors 8 through E. Sector F contains
STR8-N and is never writable through `I`.

```text
SIZE   TOP-ALIGNED RANGE  ADDRESS RANGE
 4K    E                  $E000-$EFFF
 8K    D-E                $D000-$EFFF
12K    C-E                $C000-$EFFF
16K    B-E                $B000-$EFFF
20K    A-E                $A000-$EFFF
24K    9-E                $9000-$EFFF
28K    8-E                $8000-$EFFF
```

```text
FILE                                      RANGE  CONTENT           S9
ryors-v1.2-himon-asm-bank3-8-e.s19        8-E    HIMON + ASM       $C000
ryors-v1.2-himon-bank3-c-e.s19            C-E    HIMON             $C000
ryors-v1.2-asm-bank3-8-b.s19              8-B    ASM               $FFFF
```

The combined `8-E` file is the simplest first install. To install the pieces
separately, install HIMON `C-E` first, then ASM `8-B`. The ASM-only S9 `$FFFF`
means "keep Bank 3's existing entry" and is not accepted as the first image in
an empty Bank-3 directory.

Bank 3 records one immutable S9 entry as install identity, but the operator
commands remain explicit: `C` and `W` check the HIMON marker and enter `$C000`
cold or warm respectively, while `J3` follows Bank 3's hardware RESET vector
and normally re-enters STR8-N.

## Load a temporary RAM program with HIMON

From the HIMON `>` prompt:

1. Type `L`.
2. Send the RAM-addressed S19.
3. HIMON submits S0/S1/S9 records to STR8-N's checked `$F009` `SR/02`
   service, then copies valid S1 data into RAM under its own policy. It rejects
   any nonempty span touching `$7A00-$FFFF` and fails closed before receive if
   the STR8-N service is absent or incompatible.
4. After S9, HIMON reports the byte count and start address without executing
   it. Use `G start` separately when execution is wanted; `L G` and `L F` are
   rejected by the bare-`L` grammar.

Like STR8-N recovery `L`, a HIMON `L` file need not describe a 4K-aligned or
dense flash range. HIMON's command is RAM-load-only; STR8-N owns record
parsing, while HIMON enforces destination/copy/session policy so the running
monitor and its workspace remain protected.

## If an install is interrupted

The directory records START before flash changes and COMPLETE only after the
final sector and verification succeed. A started but incomplete bank fails
closed.

- For Bank 0, 1, or 2, retry with a full `8-F` 32K install.
- For Bank 3, retry the writable payload with a full `8-E` 28K install.
- A smaller retry is refused because it could leave unknown old bytes behind.
- An interrupted first install may ask for the same `TYPE` and `DESC` again.
  They must exactly match any bytes already programmed.

Each bank has 16 START/COMPLETE transaction pairs. A failed transaction and
its full-range recovery finish the same open pair. After 16 completed pairs,
or if the directory is invalid, use the guarded onboard directory refresh
below or the external-programmer fallback.

## Refresh the directory onboard

`BUILD/v1.34/s19/str8n-v1.34-directory-refresh-2000.s19` is a dedicated
RAM-resident sector-F rewrite. It embeds the exact current 4096-byte top BIN,
whose directory is erased and whose configuration publishes B1:E as WORK at
`$FFF0=$1E` and B1:F as the protected Bank-3:F backup at `$FFF1=$1F`.
Unlike the normal top updater, it intentionally does not restore
the live `$FFB0-$FFEF` directory bytes into the candidate before programming;
both updater variants install the candidate `$FFF0-$FFF9` configuration.

The refresh otherwise uses the hardware-proven top-updater safety path. It
copies the complete live Bank-3 sector F into Bank 1 sector F, verifies that
backup, runs from RAM while Bank-3 sector F is unavailable, verifies the new
sector, and offers retry or restoration after a write failure.

Before starting, Bank 1 sector F must be replaceable. Its current contents are
replaced by a fresh exact backup of the live Bank-3 sector F, and the backup is
retained as a protected role after success.

1. At STR8-N, type `L`, then `S19`, and send
   `BUILD/v1.34/s19/str8n-v1.34-directory-refresh-2000.s19`.
2. Require the title `STR8-N 1.34 DIRECTORY REFRESH` and
   `BACKUP B1:F; TARGET B3:F`.
3. Type `BACKUP B1F` only if Bank 1 sector F may be replaced by that backup.
4. Require `BACKUP VERIFIED` and record the safe/target physical ranges and
   old-sector checksum.
5. Type the exact final confirmation `ERASE DIRECTORY`.
6. Do not press NMI or RESET, remove power, or disturb the flash/FTDI hardware
   until `DIRECTORY EMPTY; STR8-N VERIFIED; RESET` appears.

At either Directory Refresh confirmation, Enter by itself cancels before
active erase, prints `ABORT - NO ACTIVE DIRECTORY REFRESH`, and returns to
STR8-N. Any other nonmatching confirmation has the same safe result.

If active programming fails, do not reset. Type `R` to retry the erased-pocket
candidate or `O` to restore the verified old sector from Bank 1. After success,
physical RESET returns to STR8-N with D0-D3 and all install journals erased.
Bank payload sectors are unchanged, but `J0`-`J3` remain directory-gated until
the desired rows are enrolled again. Keep Bank 1 sector F intact until the
refresh and subsequent enrollment proof are accepted.

## External-programmer recovery

The programmer BIN is exactly 4096 bytes:

```text
file offset $000-$FFF  -> CPU $F000-$FFFF
                       -> physical flash $1F000-$1FFFF
```

Do not program byte zero of this file at physical device address zero. A new
top-sector BIN contains an erased directory, `$FFF0=$1E` for B1:E WORK,
`$FFF1=$1F` for the protected B1:F B3:F backup, and erased `$FFF2-$FFF9`
reserve. Writing it therefore clears all STR8-N install
journals and Bank-3 identity; existing
Bank 0-2 contents are not erased, but `J0`-`J2` remain directory-gated until
those banks are installed again through `I`.

For a directory refresh with a T48 or equivalent programmer, preserve the
rest of the device with a checked full-image merge:

1. Power the board off, remove the SST39SF010A, and read the complete 128 KiB
   device twice. Save both reads independently and require identical SHA-256
   hashes before continuing.
2. Keep both raw readbacks. Do not edit either archive.
3. Build a merged programmer image from the matched readbacks:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools/build_directory_refresh_image.ps1 `
  -ReadbackPath "PATH/board-before-directory-refresh-read-1.bin" `
  -ConfirmReadbackPath "PATH/board-before-directory-refresh-read-2.bin" `
  -OutPath "BUILD/v1.34/bin/board-directory-refreshed-20000.bin"
```

4. Require the tool to report a 131072-byte output, the current top-BIN hash,
   `CHANGED PHYSICAL = $1F000-$1FFFF only`, and `DIRECTORY REFRESH IMAGE = PASS`.
5. Load the merged 128 KiB image at programmer address zero, program the whole
   SST39SF010A, and verify all 131072 bytes against that same merged file.
6. Save the programmer's post-write readback and require its SHA-256 to equal
   the merged programmer image SHA-256.
7. Reinstall the flash with board power off, then use physical RESET. STR8-N
   remains at Bank 3 `$F000`, but D0-D3 and the Bank-3 install identity are
   erased until the desired banks are enrolled again.

The merge tool requires two distinct readback paths and refuses them unless
both files are exactly 128 KiB with identical SHA-256 hashes. It also refuses
a top BIN that is not exactly 4096 bytes, a mismatched STR8-N signature/RESET
vector, an unerased directory, role locators other than `$1E/$1F`, or non-`$FF`
bytes in `$FFF2-$FFF9`.
It never modifies either archived readback and changes only output offsets
`$1F000-$1FFFF`.

## A bank handoff is not a power-on reset

`J0`-`J3` disable IRQ, clear decimal mode, set X and the stack pointer to
`$FF`, select the bank, validate its RESET vector, and jump through that
vector. RAM and peripheral registers are otherwise preserved. A guest must
initialize the hardware state it needs and must not overwrite the VIA PCR
bank-selection bits by accident.

Physical RESET is the universal return to Bank 3.

For the picture version of these rules, see [Maps and Diagrams](MAPS.md).
For copyable sessions, see [Worked Examples](EXAMPLES.md).
